export interface DishStory {
  dishName: string;
  description: string;
  ingredientTransparency: Ingredient[];
  workerEmpowerment: WorkerEmpowerment;
  healthAndSocietyAnalysis: HealthAndSocietyAnalysis;
  preparationSteps: PreparationStep[];
  videoScriptSimulation: VideoScriptSimulation;
  nextGenerationVision: string;
}

export interface Ingredient {
  name: string;
  origin: {
    state: string;
    district: string;
    farm: string;
  };
  farmer: {
    name: string;
    age: number;
    workingHours: string;
  };
  productionMethod: string;
  journey: {
    wages: string;
    socialImpact: string;
  };
}

export interface WorkerEmpowerment {
  narrative: string;
  workers: Worker[];
}

export interface Worker {
  role: string;
  contribution: string;
  challenges: string;
  wageImpact: string;
}

export interface HealthAndSocietyAnalysis {
  comparison: string;
  healthBenefits: string;
  affordability: string;
  culturalValue: string;
}

export interface PreparationStep {
  step: number;
  description: string;
  quantity: string;
  tool: string;
  duration: string;
}

export interface VideoScriptSimulation {
  ingredient: string;
  scenes: Scene[];
}

export interface Scene {
  sceneNumber: number;
  title: string;
  visuals: string;
  duration: string;
  details: string;
  socialImpactMessage: string;
}
