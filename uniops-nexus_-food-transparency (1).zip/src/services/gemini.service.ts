import { Injectable, inject } from '@angular/core';
import { GoogleGenAI, Type } from '@google/genai';
import { DishStory } from '../models/dish.model';

@Injectable({
  providedIn: 'root',
})
export class GeminiService {
  private readonly ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  async generateDishStory(dishName: string): Promise<DishStory> {
    const prompt = `Generate a detailed, fictional but realistic story for the dish: "${dishName}". Follow the provided JSON schema precisely. The story should be engaging and highlight the principles of transparency in the food supply chain.`;
    
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: this.getDishStorySchema(),
        },
      });

      const jsonText = response.text.trim();
      const parsedData = JSON.parse(jsonText);
      
      // The model might return an object with a single root key matching the schema's root type name.
      // So we check for that and extract the data from within if needed.
      return parsedData.dishStory || parsedData;

    } catch (error) {
      console.error('Error generating dish story:', error);
      throw new Error('Failed to generate story from AI. Please check your API key and try again.');
    }
  }

  private getDishStorySchema() {
    return {
      type: Type.OBJECT,
      properties: {
        dishName: { type: Type.STRING, description: "The name of the dish." },
        description: { type: Type.STRING, description: "A brief, enticing description of the dish." },
        ingredientTransparency: {
          type: Type.ARRAY,
          description: "List of ingredients with their full transparency details.",
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              origin: {
                type: Type.OBJECT,
                properties: {
                  state: { type: Type.STRING },
                  district: { type: Type.STRING },
                  farm: { type: Type.STRING }
                }
              },
              farmer: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  age: { type: Type.INTEGER },
                  workingHours: { type: Type.STRING }
                }
              },
              productionMethod: { type: Type.STRING, description: "e.g., Manual, Modern, Organic" },
              journey: {
                type: Type.OBJECT,
                properties: {
                  wages: { type: Type.STRING, description: "Details about farmer wages related to this ingredient." },
                  socialImpact: { type: Type.STRING, description: "Social impact of sourcing this ingredient." }
                }
              }
            }
          }
        },
        workerEmpowerment: {
          type: Type.OBJECT,
          properties: {
            narrative: { type: Type.STRING, description: "Overall story of worker contributions." },
            workers: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  role: { type: Type.STRING, description: "e.g., Farmer, Cook, Textile Weaver" },
                  contribution: { type: Type.STRING },
                  challenges: { type: Type.STRING },
                  wageImpact: { type: Type.STRING }
                }
              }
            }
          }
        },
        healthAndSocietyAnalysis: {
          type: Type.OBJECT,
          properties: {
            comparison: { type: Type.STRING, description: "Traditional vs. Modern cooking methods." },
            healthBenefits: { type: Type.STRING },
            affordability: { type: Type.STRING },
            culturalValue: { type: Type.STRING }
          }
        },
        preparationSteps: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              step: { type: Type.INTEGER },
              description: { type: Type.STRING },
              quantity: { type: Type.STRING, description: "e.g., 200 grams, 1 liter, 2 pieces" },
              tool: { type: Type.STRING },
              duration: { type: Type.STRING, description: "e.g., 10 minutes, 1 hour" }
            }
          }
        },
        videoScriptSimulation: {
          type: Type.OBJECT,
          properties: {
            ingredient: { type: Type.STRING, description: "The ingredient featured in the video." },
            scenes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  sceneNumber: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  visuals: { type: Type.STRING },
                  duration: { type: Type.STRING },
                  details: { type: Type.STRING, description: "e.g., Quantity harvested, distance covered" },
                  socialImpactMessage: { type: Type.STRING }
                }
              }
            }
          }
        },
        nextGenerationVision: {
          type: Type.STRING,
          description: "A concluding vision statement."
        }
      }
    };
  }
}
