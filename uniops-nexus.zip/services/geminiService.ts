import { GoogleGenAI, Type } from "@google/genai";
import { DishData } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const modelName = "gemini-3-flash-preview";

export const generateDishStory = async (dishName: string): Promise<DishData> => {
  const prompt = `
    Create a detailed "UniOps Nexus" transparency report for the dish: "${dishName}".
    
    The report must include:
    1. Detailed ingredients with specific fictional but realistic farmer profiles (Name, Age, Location in India or relevant region, specific farm name).
    2. Worker empowerment stories for cooks and others involved.
    3. A step-by-step preparation guide with specific timings.
    4. A video script simulation showing the journey from farm to table.
    5. A health and society analysis comparing traditional vs modern methods.
    6. A futuristic vision statement for this dish.
    
    Be creative, evocative, and specific with names, places, and data.
  `;

  const response = await ai.models.generateContent({
    model: modelName,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          description: { type: Type.STRING },
          totalPrepTime: { type: Type.STRING },
          ingredients: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                origin: { type: Type.STRING },
                productionMethod: { type: Type.STRING, enum: ["Manual", "Modern", "Hybrid"] },
                quantity: { type: Type.STRING },
                story: { type: Type.STRING },
                farmer: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    age: { type: Type.NUMBER },
                    location: { type: Type.STRING },
                    farmName: { type: Type.STRING },
                    workingHours: { type: Type.STRING },
                    challenges: { type: Type.STRING },
                    wages: { type: Type.STRING },
                    impactOfTransparency: { type: Type.STRING },
                  },
                  required: ["name", "age", "location", "farmName", "workingHours", "challenges", "wages", "impactOfTransparency"],
                },
              },
              required: ["name", "origin", "productionMethod", "farmer", "quantity", "story"],
            },
          },
          workerStories: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                role: { type: Type.STRING, enum: ["Cook", "Weaver", "Transporter"] },
                name: { type: Type.STRING },
                contribution: { type: Type.STRING },
                wages: { type: Type.STRING },
                challenges: { type: Type.STRING },
                impact: { type: Type.STRING },
              },
              required: ["role", "name", "contribution", "wages", "challenges", "impact"],
            },
          },
          prepSteps: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                stepNumber: { type: Type.NUMBER },
                description: { type: Type.STRING },
                toolsUsed: { type: Type.ARRAY, items: { type: Type.STRING } },
                duration: { type: Type.STRING },
              },
              required: ["stepNumber", "description", "toolsUsed", "duration"],
            },
          },
          videoScript: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                sceneNumber: { type: Type.NUMBER },
                title: { type: Type.STRING },
                visual: { type: Type.STRING },
                duration: { type: Type.STRING },
                socialMessage: { type: Type.STRING },
              },
              required: ["sceneNumber", "title", "visual", "duration", "socialMessage"],
            },
          },
          healthAnalysis: {
            type: Type.OBJECT,
            properties: {
              traditionalVsModern: { type: Type.STRING },
              healthBenefits: { type: Type.ARRAY, items: { type: Type.STRING } },
              affordability: { type: Type.STRING },
              culturalValue: { type: Type.STRING },
            },
            required: ["traditionalVsModern", "healthBenefits", "affordability", "culturalValue"],
          },
          nextGenVision: { type: Type.STRING },
        },
        required: ["name", "description", "totalPrepTime", "ingredients", "workerStories", "prepSteps", "videoScript", "healthAnalysis", "nextGenVision"],
      },
    },
  });

  const jsonText = response.text || "{}";
  return JSON.parse(jsonText) as DishData;
};