import React from 'react';
import { Ingredient } from '../types';
import { X, MapPin, User, DollarSign, HeartHandshake, Clock, Truck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface IngredientModalProps {
  ingredient: Ingredient | null;
  isOpen: boolean;
  onClose: () => void;
}

const IngredientModal: React.FC<IngredientModalProps> = ({ ingredient, isOpen, onClose }) => {
  if (!ingredient) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            onClick={onClose}
          />
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-white rounded-3xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto flex flex-col"
          >
            {/* Header */}
            <div className="flex items-start justify-between p-6 sm:p-8 border-b border-slate-100 bg-slate-50/50 sticky top-0 z-10 backdrop-blur-md">
              <div>
                <div className="flex items-center space-x-3 mb-2">
                    <span className="px-2 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wide rounded-md">
                        Tracked Source
                    </span>
                    <span className="text-sm text-slate-500">{ingredient.origin}</span>
                </div>
                <h2 className="text-3xl font-bold text-slate-900">{ingredient.name}</h2>
              </div>
              <button 
                onClick={onClose}
                className="p-2 rounded-full hover:bg-slate-200 transition-colors text-slate-500"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 sm:p-8 space-y-8">
              {/* Farmer Profile Section */}
              <section className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
                <h3 className="text-lg font-bold text-slate-900 flex items-center mb-4">
                  <User className="w-5 h-5 mr-2 text-blue-500" />
                  Farmer Profile
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                     <div className="flex items-center space-x-4 mb-4">
                        <div className="w-16 h-16 rounded-full bg-slate-200 flex items-center justify-center text-2xl font-bold text-slate-400">
                            {ingredient.farmer.name.charAt(0)}
                        </div>
                        <div>
                            <p className="text-xl font-semibold text-slate-900">{ingredient.farmer.name}</p>
                            <p className="text-slate-500">{ingredient.farmer.age} years old • {ingredient.farmer.farmName}</p>
                        </div>
                     </div>
                     <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                            <span className="text-slate-500">Working Hours</span>
                            <span className="font-medium text-slate-800">{ingredient.farmer.workingHours}</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="text-slate-500">Wage / Income</span>
                            <span className="font-medium text-emerald-600">{ingredient.farmer.wages}</span>
                        </div>
                     </div>
                  </div>
                  <div className="space-y-4">
                    <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
                        <p className="text-xs font-bold text-slate-400 uppercase mb-1">Challenges</p>
                        <p className="text-sm text-slate-700">{ingredient.farmer.challenges}</p>
                    </div>
                    <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
                        <p className="text-xs font-bold text-slate-400 uppercase mb-1">Impact of Transparency</p>
                        <p className="text-sm text-slate-700">{ingredient.farmer.impactOfTransparency}</p>
                    </div>
                  </div>
                </div>
              </section>

              {/* Journey Timeline Simulation within Modal */}
              <section>
                <h3 className="text-lg font-bold text-slate-900 flex items-center mb-6">
                  <Truck className="w-5 h-5 mr-2 text-amber-500" />
                  Journey & Logistics
                </h3>
                <div className="relative border-l-2 border-slate-200 pl-8 space-y-8 ml-3">
                    <div className="relative">
                        <span className="absolute -left-[41px] bg-white border-2 border-slate-200 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-slate-400">1</span>
                        <h4 className="text-sm font-bold text-slate-900">Harvesting</h4>
                        <p className="text-sm text-slate-500 mt-1">Manual selection at {ingredient.farmer.farmName}.</p>
                    </div>
                    <div className="relative">
                        <span className="absolute -left-[41px] bg-white border-2 border-slate-200 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-slate-400">2</span>
                        <h4 className="text-sm font-bold text-slate-900">Transportation</h4>
                        <p className="text-sm text-slate-500 mt-1">Moved via cooperative transport to district hub.</p>
                    </div>
                    <div className="relative">
                        <span className="absolute -left-[41px] bg-emerald-500 border-2 border-emerald-500 w-6 h-6 rounded-full flex items-center justify-center">
                            <div className="w-2 h-2 bg-white rounded-full" />
                        </span>
                        <h4 className="text-sm font-bold text-slate-900">Kitchen Prep</h4>
                        <p className="text-sm text-slate-500 mt-1">Arrived fresh. {ingredient.quantity} used in preparation.</p>
                    </div>
                </div>
              </section>
              
              {/* Social Impact Callout */}
              <div className="bg-gradient-to-r from-emerald-50 to-teal-50 p-6 rounded-2xl border border-emerald-100 flex items-start space-x-4">
                <HeartHandshake className="w-8 h-8 text-emerald-500 shrink-0 mt-1" />
                <div>
                    <h4 className="text-lg font-bold text-emerald-800 mb-1">Your Impact</h4>
                    <p className="text-sm text-emerald-700/80 leading-relaxed">
                        By consuming this dish through a transparent supply chain, you directly support fair wages for {ingredient.farmer.name} and ensure sustainable {ingredient.productionMethod.toLowerCase()} farming practices continue in {ingredient.origin}.
                    </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default IngredientModal;