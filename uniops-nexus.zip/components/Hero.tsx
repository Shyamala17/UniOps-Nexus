import React, { useState } from 'react';
import { Search, ArrowRight, Activity, Leaf, Users } from 'lucide-react';
import { motion } from 'framer-motion';

interface HeroProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
}

const Hero: React.FC<HeroProps> = ({ onSearch, isLoading }) => {
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onSearch(query);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { duration: 0.8, staggerChildren: 0.2 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="relative min-h-screen bg-slate-900 overflow-hidden flex flex-col justify-center items-center text-white p-6">
      {/* Background Abstract Shapes */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 pointer-events-none">
        <div className="absolute -top-[20%] -left-[10%] w-[60%] h-[60%] bg-emerald-500/10 rounded-full blur-[120px]" />
        <div className="absolute top-[40%] -right-[10%] w-[50%] h-[50%] bg-blue-500/10 rounded-full blur-[120px]" />
        <div className="absolute -bottom-[10%] left-[20%] w-[40%] h-[40%] bg-amber-500/10 rounded-full blur-[100px]" />
      </div>

      <motion.div 
        className="z-10 max-w-4xl w-full text-center"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="mb-6 flex justify-center space-x-2">
            <span className="px-3 py-1 bg-white/10 border border-white/20 rounded-full text-xs font-medium tracking-wider uppercase text-emerald-400">
                Transparency Reimagined
            </span>
        </motion.div>

        <motion.h1 variants={itemVariants} className="text-5xl md:text-7xl font-bold tracking-tight mb-6 bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
          UniOps Nexus
        </motion.h1>
        
        <motion.p variants={itemVariants} className="text-lg md:text-xl text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">
          Every dish has a hidden story. Discover the farmers, the journey, and the impact behind your next meal.
        </motion.p>

        <motion.form variants={itemVariants} onSubmit={handleSubmit} className="relative max-w-lg mx-auto mb-16 group">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-slate-400 group-focus-within:text-emerald-400 transition-colors" />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="What are you eating today? (e.g., Paneer Butter Masala)"
            className="w-full pl-12 pr-12 py-4 bg-white/5 border border-white/10 rounded-2xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all backdrop-blur-sm text-lg shadow-xl"
            disabled={isLoading}
          />
          <button 
            type="button" 
            onClick={handleSubmit}
            className="absolute inset-y-2 right-2 p-2 bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-white"
            disabled={isLoading || !query.trim()}
          >
            {isLoading ? (
               <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
               <ArrowRight className="h-5 w-5" />
            )}
          </button>
        </motion.form>

        <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors backdrop-blur-sm">
                <Leaf className="w-8 h-8 text-emerald-400 mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Ingredient Traceability</h3>
                <p className="text-sm text-slate-400">Track every grain back to the specific farm and soil it grew in.</p>
            </div>
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors backdrop-blur-sm">
                <Users className="w-8 h-8 text-blue-400 mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Worker Empowerment</h3>
                <p className="text-sm text-slate-400">See the faces and wages of the people who made your meal possible.</p>
            </div>
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors backdrop-blur-sm">
                <Activity className="w-8 h-8 text-amber-400 mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">Health & Impact</h3>
                <p className="text-sm text-slate-400">Analyze the nutritional and societal cost of modern vs. traditional methods.</p>
            </div>
        </motion.div>
      </motion.div>
      
      {/* Footer-ish */}
      <div className="absolute bottom-6 text-slate-500 text-xs text-center w-full">
        Powered by Gemini 2.0 Flash • UniOps Transparent Systems
      </div>
    </div>
  );
};

export default Hero;