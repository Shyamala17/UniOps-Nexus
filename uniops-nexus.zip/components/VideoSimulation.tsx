import React from 'react';
import { VideoScene } from '../types';
import { Play, SkipForward, Film, MonitorPlay } from 'lucide-react';

interface VideoSimulationProps {
  script: VideoScene[];
}

const VideoSimulation: React.FC<VideoSimulationProps> = ({ script }) => {
  return (
    <div className="space-y-6">
      <div className="bg-slate-900 rounded-3xl overflow-hidden shadow-2xl">
        {/* Mock Video Player Header */}
        <div className="bg-black/40 backdrop-blur-md p-4 flex justify-between items-center border-b border-white/10">
            <div className="flex items-center space-x-2 text-white/70">
                <Film className="w-5 h-5" />
                <span className="text-sm font-medium tracking-wide">UniOps Media Player // Sequence_001</span>
            </div>
            <div className="flex space-x-1">
                <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
            </div>
        </div>

        {/* Script Visualization */}
        <div className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {script.map((scene, idx) => (
                    <div key={idx} className="relative group">
                        {/* Connecting Line */}
                        {idx < script.length - 1 && (
                            <div className="hidden lg:block absolute top-1/2 -right-6 w-8 h-0.5 bg-slate-700 z-0" />
                        )}

                        <div className="relative bg-slate-800 rounded-xl p-1 border border-slate-700 hover:border-emerald-500/50 transition-colors z-10 h-full flex flex-col">
                            {/* Visual Thumbnail Placeholder */}
                            <div className="aspect-video bg-slate-900 rounded-lg mb-3 flex items-center justify-center relative overflow-hidden">
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                                <span className="relative z-10 text-4xl font-black text-slate-700 select-none">{scene.sceneNumber}</span>
                                <MonitorPlay className="absolute top-2 right-2 w-4 h-4 text-emerald-500" />
                                <div className="absolute bottom-2 left-2 right-2 text-xs text-white/80 line-clamp-2 leading-tight font-medium">
                                    {scene.visual}
                                </div>
                            </div>

                            <div className="px-2 pb-3 flex-1 flex flex-col">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="text-sm font-bold text-white leading-tight">{scene.title}</h4>
                                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-400/10 px-1.5 py-0.5 rounded ml-2 whitespace-nowrap">
                                        {scene.duration}
                                    </span>
                                </div>
                                <p className="text-xs text-slate-400 mt-auto pt-2 border-t border-slate-700/50">
                                    <span className="text-slate-500 uppercase font-bold text-[10px]">Impact: </span>
                                    {scene.socialMessage}
                                </p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Timeline Bar */}
            <div className="mt-8 bg-slate-800 h-12 rounded-lg flex items-center px-4 space-x-4 border border-slate-700">
                <Play className="w-4 h-4 text-white fill-current" />
                <div className="flex-1 h-1 bg-slate-700 rounded-full relative overflow-hidden">
                    <div className="absolute left-0 top-0 bottom-0 w-1/3 bg-emerald-500 rounded-full" />
                </div>
                <span className="text-xs font-mono text-slate-400">00:45 / 03:20</span>
                <SkipForward className="w-4 h-4 text-slate-400" />
            </div>
        </div>
      </div>
    </div>
  );
};

export default VideoSimulation;