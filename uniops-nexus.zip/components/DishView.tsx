import React, { useState } from 'react';
import { DishData, Ingredient } from '../types';
import { Clock, Users, Video, Activity, Info, ChevronLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import IngredientCard from './IngredientCard';
import WorkerStory from './WorkerStory';
import Timeline from './Timeline';
import VideoSimulation from './VideoSimulation';
import HealthAnalysis from './HealthAnalysis';
import IngredientModal from './IngredientModal';

interface DishViewProps {
  data: DishData;
  onBack: () => void;
}

const tabs = [
  { id: 'ingredients', label: 'Ingredients', icon: Info },
  { id: 'workers', label: 'Workers', icon: Users },
  { id: 'prep', label: 'Preparation', icon: Clock },
  { id: 'video', label: 'Journey', icon: Video },
  { id: 'health', label: 'Analysis', icon: Activity },
];

const DishView: React.FC<DishViewProps> = ({ data, onBack }) => {
  const [activeTab, setActiveTab] = useState('ingredients');
  const [selectedIngredient, setSelectedIngredient] = useState<Ingredient | null>(null);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button 
              onClick={onBack}
              className="p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-600"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-900">{data.name}</h1>
              <p className="text-xs text-slate-500 truncate max-w-xs sm:max-w-md">{data.description}</p>
            </div>
          </div>
          <div className="hidden sm:flex items-center space-x-2 text-sm text-slate-500 bg-slate-100 px-3 py-1 rounded-full">
            <Clock className="w-4 h-4" />
            <span>{data.totalPrepTime} Total Time</span>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-1 overflow-x-auto no-scrollbar py-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`
                    flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all whitespace-nowrap
                    ${isActive 
                      ? 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200 shadow-sm' 
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}
                  `}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-500' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'ingredients' && (
              <div className="space-y-6">
                 <div className="flex justify-between items-end mb-4">
                    <h2 className="text-2xl font-bold text-slate-800">Ingredient Transparency</h2>
                    <span className="text-sm text-slate-500 italic">Click an ingredient for the full journey</span>
                 </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {data.ingredients.map((ing, idx) => (
                      <IngredientCard 
                        key={idx} 
                        ingredient={ing} 
                        onClick={() => setSelectedIngredient(ing)} 
                      />
                    ))}
                 </div>
              </div>
            )}

            {activeTab === 'workers' && (
              <div className="space-y-6">
                 <h2 className="text-2xl font-bold text-slate-800 mb-4">Worker Empowerment</h2>
                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                   {data.workerStories.map((worker, idx) => (
                     <WorkerStory key={idx} story={worker} />
                   ))}
                 </div>
              </div>
            )}

            {activeTab === 'prep' && (
              <div className="space-y-6">
                 <h2 className="text-2xl font-bold text-slate-800 mb-4">Preparation & Timing</h2>
                 <Timeline steps={data.prepSteps} totalTime={data.totalPrepTime} />
              </div>
            )}

            {activeTab === 'video' && (
              <div className="space-y-6">
                 <h2 className="text-2xl font-bold text-slate-800 mb-4">Supply Chain Cinema</h2>
                 <VideoSimulation script={data.videoScript} />
              </div>
            )}

            {activeTab === 'health' && (
              <div className="space-y-6">
                 <h2 className="text-2xl font-bold text-slate-800 mb-4">Health & Society Analysis</h2>
                 <HealthAnalysis analysis={data.healthAnalysis} />
                 
                 {/* Next Gen Vision - Usually fits well with society analysis */}
                 <div className="mt-12 p-8 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/20 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none" />
                    <h3 className="text-xl font-bold text-emerald-400 mb-4 relative z-10">Next-Generation Vision</h3>
                    <p className="text-lg leading-relaxed text-slate-300 relative z-10">
                      {data.nextGenVision}
                    </p>
                 </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Modals */}
      <IngredientModal 
        ingredient={selectedIngredient} 
        isOpen={!!selectedIngredient} 
        onClose={() => setSelectedIngredient(null)} 
      />
    </div>
  );
};

export default DishView;