import React from 'react';
import { HealthAnalysis as HealthAnalysisType } from '../types';
import { Activity, Scale, Heart, Coins } from 'lucide-react';

interface HealthAnalysisProps {
  analysis: HealthAnalysisType;
}

const HealthAnalysis: React.FC<HealthAnalysisProps> = ({ analysis }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      
      {/* Traditional vs Modern Card */}
      <div className="col-span-1 md:col-span-2 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-8 border border-blue-100">
        <div className="flex items-center mb-4">
            <div className="p-2 bg-blue-100 text-blue-600 rounded-lg mr-3">
                <Scale className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-blue-900">Traditional vs. Modern Analysis</h3>
        </div>
        <p className="text-blue-800/80 leading-relaxed text-lg">
            {analysis.traditionalVsModern}
        </p>
      </div>

      {/* Health Benefits */}
      <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
        <div className="flex items-center mb-6">
            <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg mr-3">
                <Heart className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Health Benefits</h3>
        </div>
        <ul className="space-y-3">
            {analysis.healthBenefits.map((benefit, idx) => (
                <li key={idx} className="flex items-start">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 mr-3" />
                    <span className="text-slate-600">{benefit}</span>
                </li>
            ))}
        </ul>
      </div>

      {/* Society & Cost */}
      <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm flex flex-col justify-between">
        <div>
            <div className="flex items-center mb-6">
                <div className="p-2 bg-amber-100 text-amber-600 rounded-lg mr-3">
                    <Coins className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Society & Value</h3>
            </div>
            
            <div className="mb-6">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">Affordability</h4>
                <p className="text-slate-700 font-medium">{analysis.affordability}</p>
            </div>
            
            <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wide mb-1">Cultural Significance</h4>
                <p className="text-slate-700 font-medium">{analysis.culturalValue}</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default HealthAnalysis;