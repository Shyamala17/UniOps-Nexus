import React from 'react';
import { WorkerStory as WorkerStoryType } from '../types';
import { Quote, Briefcase, TrendingUp } from 'lucide-react';

interface WorkerStoryProps {
  story: WorkerStoryType;
}

const WorkerStory: React.FC<WorkerStoryProps> = ({ story }) => {
  return (
    <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 flex flex-col h-full">
      <div className="flex items-center space-x-4 mb-6">
        <div className="w-12 h-12 bg-slate-900 text-white rounded-full flex items-center justify-center font-bold text-lg">
            {story.name.charAt(0)}
        </div>
        <div>
            <h3 className="text-xl font-bold text-slate-900">{story.name}</h3>
            <span className="inline-block bg-slate-100 text-slate-600 text-xs px-2 py-1 rounded-md font-medium uppercase tracking-wide">
                {story.role}
            </span>
        </div>
      </div>

      <div className="relative mb-6">
        <Quote className="absolute -top-2 -left-2 w-8 h-8 text-slate-100 -z-10 transform -scale-x-100" />
        <p className="text-slate-600 italic leading-relaxed">
            "{story.contribution}"
        </p>
      </div>

      <div className="mt-auto space-y-4">
        <div className="flex items-start space-x-3">
            <Briefcase className="w-5 h-5 text-slate-400 mt-0.5" />
            <div>
                <p className="text-sm font-bold text-slate-900">The Challenge</p>
                <p className="text-sm text-slate-500">{story.challenges}</p>
            </div>
        </div>
        
        <div className="flex items-start space-x-3">
            <TrendingUp className="w-5 h-5 text-emerald-500 mt-0.5" />
            <div>
                <p className="text-sm font-bold text-emerald-700">Transparency Impact</p>
                <p className="text-sm text-emerald-600/80">{story.impact}</p>
            </div>
        </div>

        <div className="pt-4 border-t border-slate-100">
            <div className="flex justify-between items-center text-sm">
                <span className="text-slate-500">Monthly Earnings</span>
                <span className="font-bold text-slate-900 bg-slate-50 px-3 py-1 rounded-full border border-slate-100">
                    {story.wages}
                </span>
            </div>
        </div>
      </div>
    </div>
  );
};

export default WorkerStory;