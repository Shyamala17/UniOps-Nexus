import React from 'react';
import { Ingredient } from '../types';
import { MapPin, User, Sprout, ArrowUpRight } from 'lucide-react';
import { motion } from 'framer-motion';

interface IngredientCardProps {
  ingredient: Ingredient;
  onClick: () => void;
}

const IngredientCard: React.FC<IngredientCardProps> = ({ ingredient, onClick }) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 cursor-pointer hover:shadow-md transition-shadow group relative overflow-hidden"
      onClick={onClick}
    >
      <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="p-2 bg-slate-50 rounded-full">
            <ArrowUpRight className="w-4 h-4 text-slate-400" />
        </div>
      </div>

      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-bold text-slate-900">{ingredient.name}</h3>
          <span className="text-xs font-medium px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 mt-1 inline-block">
            {ingredient.quantity}
          </span>
        </div>
        <div className={`p-2 rounded-xl ${ingredient.productionMethod === 'Modern' ? 'bg-blue-50 text-blue-600' : 'bg-emerald-50 text-emerald-600'}`}>
          <Sprout className="w-5 h-5" />
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-start space-x-3 text-sm text-slate-600">
          <MapPin className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
          <span>{ingredient.origin}</span>
        </div>
        
        <div className="flex items-start space-x-3 text-sm text-slate-600">
          <User className="w-4 h-4 text-slate-400 mt-0.5 shrink-0" />
          <div className="flex flex-col">
            <span className="font-medium text-slate-800">{ingredient.farmer.name}, {ingredient.farmer.age}</span>
            <span className="text-xs text-slate-400">{ingredient.farmer.farmName}</span>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-100 mt-3">
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wide">Production Method</span>
            <p className="text-sm text-slate-700 mt-1">{ingredient.productionMethod}</p>
        </div>
      </div>
      
      <div className="mt-4 pt-3 bg-slate-50 -mx-6 -mb-6 px-6 py-3 border-t border-slate-100 flex justify-between items-center">
        <span className="text-xs text-slate-500 font-medium">View full journey</span>
        <ArrowUpRight className="w-4 h-4 text-emerald-500" />
      </div>
    </motion.div>
  );
};

export default IngredientCard;