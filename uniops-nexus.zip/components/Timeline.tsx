import React from 'react';
import { PrepStep } from '../types';
import { Timer, Wrench } from 'lucide-react';
import { motion } from 'framer-motion';

interface TimelineProps {
  steps: PrepStep[];
  totalTime: string;
}

const Timeline: React.FC<TimelineProps> = ({ steps, totalTime }) => {
  return (
    <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm relative overflow-hidden">
      <div className="absolute top-0 right-0 p-8 opacity-5">
        <Timer className="w-64 h-64" />
      </div>

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold text-slate-900">Process Flow</h3>
            <span className="px-4 py-2 bg-slate-900 text-white rounded-full text-sm font-bold shadow-lg">
                Total: {totalTime}
            </span>
        </div>

        <div className="space-y-8 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-300 before:to-transparent">
          {steps.map((step, index) => (
            <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active"
            >
              <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-white bg-slate-200 group-hover:bg-emerald-500 group-hover:text-white transition-colors shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow-sm text-slate-500 font-bold z-10">
                {step.stepNumber}
              </div>
              
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start mb-2">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Step {step.stepNumber}</span>
                    <div className="flex items-center text-xs text-emerald-600 font-medium bg-emerald-50 px-2 py-1 rounded">
                        <Timer className="w-3 h-3 mr-1" />
                        {step.duration}
                    </div>
                </div>
                <p className="text-slate-800 font-medium mb-3">{step.description}</p>
                <div className="flex flex-wrap gap-2">
                    {step.toolsUsed.map((tool, i) => (
                        <span key={i} className="inline-flex items-center text-xs text-slate-500 bg-white border border-slate-200 px-2 py-1 rounded-md">
                            <Wrench className="w-3 h-3 mr-1 opacity-50" />
                            {tool}
                        </span>
                    ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Timeline;