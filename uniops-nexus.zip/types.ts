export interface Farmer {
  name: string;
  age: number;
  location: string; // state, district
  farmName: string;
  workingHours: string;
  challenges: string;
  wages: string;
  impactOfTransparency: string;
}

export interface Ingredient {
  name: string;
  origin: string;
  productionMethod: 'Manual' | 'Modern' | 'Hybrid';
  farmer: Farmer;
  quantity: string;
  story: string; // Short narrative
}

export interface WorkerStory {
  role: 'Cook' | 'Weaver' | 'Transporter';
  name: string;
  contribution: string;
  wages: string;
  challenges: string;
  impact: string;
}

export interface PrepStep {
  stepNumber: number;
  description: string;
  toolsUsed: string[];
  duration: string;
}

export interface VideoScene {
  sceneNumber: number;
  title: string;
  visual: string;
  duration: string;
  socialMessage: string;
}

export interface HealthAnalysis {
  traditionalVsModern: string;
  healthBenefits: string[];
  affordability: string;
  culturalValue: string;
}

export interface DishData {
  name: string;
  description: string;
  totalPrepTime: string;
  ingredients: Ingredient[];
  workerStories: WorkerStory[];
  prepSteps: PrepStep[];
  videoScript: VideoScene[];
  healthAnalysis: HealthAnalysis;
  nextGenVision: string;
}

export enum AppState {
  HOME,
  LOADING,
  DISH_VIEW
}