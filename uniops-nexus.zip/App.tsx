import React, { useState } from 'react';
import Hero from './components/Hero';
import DishView from './components/DishView';
import { generateDishStory } from './services/geminiService';
import { DishData, AppState } from './types';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.HOME);
  const [dishData, setDishData] = useState<DishData | null>(null);

  const handleSearch = async (query: string) => {
    setAppState(AppState.LOADING);
    try {
      const data = await generateDishStory(query);
      setDishData(data);
      setAppState(AppState.DISH_VIEW);
    } catch (error) {
      console.error("Failed to generate dish story:", error);
      setAppState(AppState.HOME);
      // In a real app, show a toast error here
      alert("Failed to find details for this dish. Please try again.");
    }
  };

  const handleBack = () => {
    setAppState(AppState.HOME);
    setDishData(null);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {appState === AppState.HOME && (
        <Hero onSearch={handleSearch} isLoading={false} />
      )}
      
      {appState === AppState.LOADING && (
        <Hero onSearch={() => {}} isLoading={true} />
      )}

      {appState === AppState.DISH_VIEW && dishData && (
        <DishView data={dishData} onBack={handleBack} />
      )}
    </div>
  );
};

export default App;