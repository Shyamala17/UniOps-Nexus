
import { Component, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GoogleGenAI, Type } from '@google/genai';

interface CarrotCurryAnalysis {
  ingredientsList: string[];
  origins: {
    ingredient: string;
    description: string;
  }[];
  farmerDetails: string[];
  productionMethods: string[];
  socialImpact: string[];
  cookingComparison: {
    healthBenefits: string[];
    affordability: string[];
    culturalValue: string[];
  };
}

@Component({
  standalone: true,
  imports: [CommonModule],
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [], // Tailwind handles styling
  host: {
    class: 'block w-full max-w-4xl bg-white shadow-lg rounded-xl p-8'
  }
})
export class AppComponent implements OnInit {
  analysisResult = signal<CarrotCurryAnalysis | null>(null);
  isLoading = signal(false);
  error = signal<string | null>(null);

  ngOnInit() {
    this.analyzeCarrotCurry();
  }

  async analyzeCarrotCurry() {
    this.isLoading.set(true);
    this.error.set(null);

    if (!process.env.API_KEY) {
      this.error.set("API Key is not configured. Please set process.env.API_KEY.");
      this.isLoading.set(false);
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Analyze the dish "Carrot Curry" based on the following categories. Provide detailed yet concise points for each category:
      1. Ingredients list (list all common ingredients).
      2. Origin of each primary ingredient: For each primary ingredient, detail its origin (state, district, and if possible, a specific farm or region type like 'small family farm in [district]').
      3. Farmer details related to the main vegetable/spice: For the primary vegetable (carrot) and main spices, provide typical farmer details (e.g., a representative name and age, typical daily working hours, and general working conditions).
      4. Production method of main ingredients: For main ingredients, describe the production method (manual vs. modern, including specific techniques or machinery used).
      5. Social impact: Elaborate on the social impact, covering typical wages for farmers/laborers involved in primary ingredient production, the general affordability of Carrot Curry, and its overall health value.
      6. Traditional vs. Modern Cooking Comparison for Carrot Curry: Compare traditional cooking methods versus modern kitchen technologies for Carrot Curry.
         - Health benefits: Discuss how each method impacts the nutritional value and health aspects.
         - Affordability: Analyze the cost implications (e.g., fuel, equipment, ingredient sourcing).
         - Cultural value: Explain how each method preserves or alters the cultural significance and experience.
      
      Structure your response as a JSON object strictly following the schema below.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              ingredientsList: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'A list of common ingredients in Carrot Curry.'
              },
              origins: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    ingredient: { type: Type.STRING, description: 'The name of the ingredient.' },
                    description: { type: Type.STRING, description: 'Description of the origin (state, district, farm/region).' }
                  },
                  propertyOrdering: ["ingredient", "description"]
                },
                description: 'Detailed origins for primary ingredients.'
              },
              farmerDetails: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Details about farmers of key ingredients (e.g., typical age, working hours, general characteristics).'
              },
              productionMethods: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Description of production methods for key ingredients (manual vs modern).'
              },
              socialImpact: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Analysis of social impact (wages, affordability, health value).'
              },
              cookingComparison: {
                type: Type.OBJECT,
                properties: {
                  healthBenefits: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Comparison of health benefits between traditional and modern cooking.'
                  },
                  affordability: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Comparison of affordability between traditional and modern cooking.'
                  },
                  culturalValue: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: 'Comparison of cultural value between traditional and modern cooking.'
                  }
                },
                propertyOrdering: ["healthBenefits", "affordability", "culturalValue"]
              }
            },
            propertyOrdering: ["ingredientsList", "origins", "farmerDetails", "productionMethods", "socialImpact", "cookingComparison"]
          },
        },
      });

      const jsonStr = response.text.trim();
      if (jsonStr) {
        this.analysisResult.set(JSON.parse(jsonStr));
      } else {
        this.error.set("Received an empty response from the AI.");
      }

    } catch (e: any) {
      console.error("API Error:", e);
      this.error.set(`Failed to analyze: ${e.message || 'Unknown error'}. Please try again.`);
    } finally {
      this.isLoading.set(false);
    }
  }
}
