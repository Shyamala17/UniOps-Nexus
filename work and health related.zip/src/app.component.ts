
import { Component, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GoogleGenAI, Type } from '@google/genai';

interface CarrotCurryAnalysis {
  ingredientsList: string[];
  origins: {
    ingredient: string;
    description: string;
  }[];
  farmerDetails: string[];
  productionMethods: string[];
  socialImpact: string[];
}

@Component({
  standalone: true,
  imports: [CommonModule],
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [], // Tailwind handles styling
  host: {
    class: 'block w-full max-w-4xl bg-white shadow-lg rounded-xl p-8'
  }
})
export class AppComponent implements OnInit {
  analysisResult = signal<CarrotCurryAnalysis | null>(null);
  isLoading = signal(false);
  error = signal<string | null>(null);

  ngOnInit() {
    this.analyzeCarrotCurry();
  }

  async analyzeCarrotCurry() {
    this.isLoading.set(true);
    this.error.set(null);

    if (!process.env.API_KEY) {
      this.error.set("API Key is not configured. Please set process.env.API_KEY.");
      this.isLoading.set(false);
      return;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Analyze the dish "Carrot Curry" based on the following categories. Provide detailed yet concise points for each category:
      1. Ingredients list (list all common ingredients)
      2. Origin of each primary ingredient (state, district, farm, or general region if specific farm is unknown)
      3. Farmer details related to the main vegetable/spice (name, age, working hours, or typical characteristics if specific names are unknown)
      4. Production method of main ingredients (manual vs modern, and description)
      5. Social impact (wages for farmers/laborers, affordability of the dish, health value).
      
      Structure your response as a JSON object strictly following the schema below.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              ingredientsList: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'A list of common ingredients in Carrot Curry.'
              },
              origins: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    ingredient: { type: Type.STRING, description: 'The name of the ingredient.' },
                    description: { type: Type.STRING, description: 'Description of the origin (state, district, farm/region).' }
                  },
                  propertyOrdering: ["ingredient", "description"]
                },
                description: 'Detailed origins for primary ingredients.'
              },
              farmerDetails: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Details about farmers of key ingredients (e.g., typical age, working hours, general characteristics).'
              },
              productionMethods: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Description of production methods for key ingredients (manual vs modern).'
              },
              socialImpact: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'Analysis of social impact (wages, affordability, health value).'
              }
            },
            propertyOrdering: ["ingredientsList", "origins", "farmerDetails", "productionMethods", "socialImpact"]
          },
        },
      });

      const jsonStr = response.text.trim();
      if (jsonStr) {
        this.analysisResult.set(JSON.parse(jsonStr));
      } else {
        this.error.set("Received an empty response from the AI.");
      }

    } catch (e: any) {
      console.error("API Error:", e);
      this.error.set(`Failed to analyze: ${e.message || 'Unknown error'}. Please try again.`);
    } finally {
      this.isLoading.set(false);
    }
  }
}
    