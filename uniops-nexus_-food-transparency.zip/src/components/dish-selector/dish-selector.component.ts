import { Component, ChangeDetectionStrategy, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

interface Dish {
  name: string;
  image: string;
  description: string;
}

@Component({
  selector: 'app-dish-selector',
  template: `
    <div class="p-8">
      <div class="text-center mb-12">
        <h1 class="text-4xl md:text-5xl font-bold text-nexus-dark">
          Discover the Story Behind Your Food
        </h1>
        <p class="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
          Select a dish to uncover its journey from the farm to your plate. We believe in complete transparency for a healthier and fairer world.
        </p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        @for (dish of dishes(); track dish.name) {
          <div 
            (click)="selectDish.emit(dish.name)"
            class="bg-white rounded-lg shadow-lg overflow-hidden cursor-pointer transform hover:scale-105 transition-transform duration-300 group">
            <img [src]="dish.image" [alt]="dish.name" class="w-full h-48 object-cover">
            <div class="p-6">
              <h3 class="text-2xl font-semibold text-nexus-dark group-hover:text-nexus-green transition-colors duration-300">{{ dish.name }}</h3>
              <p class="text-gray-500 mt-2">{{ dish.description }}</p>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DishSelectorComponent {
  selectDish = output<string>();

  dishes = signal<Dish[]>([
    {
      name: 'Paneer Butter Masala',
      image: 'https://picsum.photos/seed/paneer/400/300',
      description: 'A creamy and rich curry made with fresh cottage cheese in a tomato-based sauce.'
    },
    {
      name: 'Vegetable Biryani',
      image: 'https://picsum.photos/seed/biryani/400/300',
      description: 'A fragrant and aromatic rice dish layered with mixed vegetables and exotic spices.'
    },
    {
      name: 'Dal Makhani',
      image: 'https://picsum.photos/seed/dal/400/300',
      description: 'Slow-cooked black lentils and kidney beans in a buttery, creamy tomato gravy.'
    },
     {
      name: 'Masala Dosa',
      image: 'https://picsum.photos/seed/dosa/400/300',
      description: 'A South Indian fermented crepe made from rice batter and black lentils, with a potato filling.'
    },
    {
      name: 'Chole Bhature',
      image: 'https://picsum.photos/seed/chole/400/300',
      description: 'A spicy chickpea curry paired with fluffy, deep-fried bread.'
    },
    {
      name: 'Samosa',
      image: 'https://picsum.photos/seed/samosa/400/300',
      description: 'A fried or baked pastry with a savory filling, such as spiced potatoes, onions, and peas.'
    }
  ]);
}
