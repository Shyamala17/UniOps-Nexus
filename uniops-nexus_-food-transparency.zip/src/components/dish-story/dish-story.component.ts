import { Component, ChangeDetectionStrategy, input, signal, effect, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GeminiService } from '../../services/gemini.service';
import { DishStory, Ingredient } from '../../models/dish.model';

type Tab = 
  | 'ingredients' 
  | 'workers' 
  | 'health' 
  | 'prep' 
  | 'video' 
  | 'vision';

@Component({
  selector: 'app-dish-story',
  template: `
    <div class="p-4 md:p-8 max-w-7xl mx-auto">
      @if (isLoading()) {
        <div class="flex flex-col items-center justify-center h-96">
          <svg class="animate-spin -ml-1 mr-3 h-10 w-10 text-nexus-green" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p class="mt-4 text-lg text-gray-600">Uncovering the story of {{ dishName() }}... This can take a moment.</p>
        </div>
      }

      @if (error()) {
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
          <strong class="font-bold">An error occurred:</strong>
          <span class="block sm:inline">{{ error() }}</span>
        </div>
      }

      @if (story(); as data) {
        <div class="bg-white rounded-xl shadow-2xl p-6 md:p-8">
          <h1 class="text-4xl md:text-5xl font-extrabold text-nexus-dark mb-2">{{ data.dishName }}</h1>
          <p class="text-gray-500 text-lg mb-8">{{ data.description }}</p>

          <!-- Tabs -->
          <div class="border-b border-gray-200 mb-6">
            <nav class="-mb-px flex flex-wrap gap-x-6" aria-label="Tabs">
              @for (tab of tabs; track tab.id) {
                <button
                  (click)="activeTab.set(tab.id)"
                  [class.text-nexus-green]="activeTab() === tab.id"
                  [class.border-nexus-green]="activeTab() === tab.id"
                  [class.text-gray-500]="activeTab() !== tab.id"
                  [class.border-transparent]="activeTab() !== tab.id"
                  class="shrink-0 border-b-2 py-4 px-1 text-sm font-medium hover:border-gray-300 hover:text-gray-700 transition-colors">
                  {{ tab.name }}
                </button>
              }
            </nav>
          </div>

          <!-- Tab Content -->
          <div class="animate-fade-in">
            @if (activeTab() === 'ingredients') {
              <div>
                <h2 class="text-2xl font-bold text-nexus-dark mb-4">Ingredient Transparency</h2>
                <div class="space-y-4">
                  @for (ing of data.ingredientTransparency; track ing.name) {
                    <div class="bg-gray-50 p-4 rounded-lg border border-gray-200 cursor-pointer hover:bg-nexus-light-green/20" (click)="toggleIngredientDetails(ing)">
                       <div class="flex justify-between items-center">
                         <h3 class="text-lg font-semibold text-nexus-dark">{{ ing.name }}</h3>
                         <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" 
                              class="w-6 h-6 text-gray-400 transition-transform"
                              [class.rotate-180]="selectedIngredient() === ing">
                           <path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5" />
                         </svg>
                       </div>

                      @if (selectedIngredient() === ing) {
                        <div class="mt-4 pt-4 border-t border-gray-200 animate-fade-in">
                          <p><strong>Origin:</strong> {{ing.origin.farm}}, {{ing.origin.district}}, {{ing.origin.state}}</p>
                          <p><strong>Farmer:</strong> {{ing.farmer.name}} (Age: {{ing.farmer.age}}, Hours: {{ing.farmer.workingHours}})</p>
                          <p><strong>Method:</strong> {{ing.productionMethod}}</p>
                          <p><strong>Wages:</strong> {{ing.journey.wages}}</p>
                          <p><strong>Impact:</strong> {{ing.journey.socialImpact}}</p>
                        </div>
                      }
                    </div>
                  }
                </div>
              </div>
            }
            @if (activeTab() === 'workers') {
              <div>
                <h2 class="text-2xl font-bold text-nexus-dark mb-4">Worker Empowerment</h2>
                <p class="mb-6 text-gray-600">{{ data.workerEmpowerment.narrative }}</p>
                <div class="space-y-4">
                  @for (worker of data.workerEmpowerment.workers; track worker.role) {
                    <div class="bg-gray-50 p-4 rounded-lg border">
                      <h3 class="font-semibold text-lg text-nexus-dark">{{ worker.role }}</h3>
                      <p><strong>Contribution:</strong> {{ worker.contribution }}</p>
                      <p><strong>Challenges:</strong> {{ worker.challenges }}</p>
                      <p><strong>Wage Impact:</strong> {{ worker.wageImpact }}</p>
                    </div>
                  }
                </div>
              </div>
            }
            @if (activeTab() === 'health') {
              <div class="space-y-4">
                <h2 class="text-2xl font-bold text-nexus-dark mb-4">Health & Society</h2>
                <div><h3 class="font-semibold">Comparison:</h3><p>{{data.healthAndSocietyAnalysis.comparison}}</p></div>
                <div><h3 class="font-semibold">Health Benefits:</h3><p>{{data.healthAndSocietyAnalysis.healthBenefits}}</p></div>
                <div><h3 class="font-semibold">Affordability:</h3><p>{{data.healthAndSocietyAnalysis.affordability}}</p></div>
                <div><h3 class="font-semibold">Cultural Value:</h3><p>{{data.healthAndSocietyAnalysis.culturalValue}}</p></div>
              </div>
            }
            @if (activeTab() === 'prep') {
              <div>
                <h2 class="text-2xl font-bold text-nexus-dark mb-4">Preparation Steps</h2>
                <ol class="relative border-l border-gray-200 space-y-6 ml-4">
                  @for (step of data.preparationSteps; track step.step) {
                    <li class="ml-6">
                      <span class="absolute flex items-center justify-center w-8 h-8 bg-nexus-light-green rounded-full -left-4 ring-8 ring-white">
                         {{step.step}}
                      </span>
                      <h3 class="font-semibold text-lg">{{step.description}}</h3>
                      <p class="text-sm text-gray-500">
                        {{step.quantity}} | {{step.tool}} | {{step.duration}}
                      </p>
                    </li>
                  }
                </ol>
              </div>
            }
            @if (activeTab() === 'video') {
              <div>
                <h2 class="text-2xl font-bold text-nexus-dark mb-4">Video Simulation: Journey of {{data.videoScriptSimulation.ingredient}}</h2>
                <div class="space-y-4">
                  @for (scene of data.videoScriptSimulation.scenes; track scene.sceneNumber) {
                    <div class="bg-gray-50 p-4 rounded-lg border">
                      <h3 class="font-semibold text-lg">Scene {{scene.sceneNumber}}: {{scene.title}} ({{scene.duration}})</h3>
                      <p><strong>Visuals:</strong> {{scene.visuals}}</p>
                      <p><strong>Details:</strong> {{scene.details}}</p>
                      <p class="mt-2 p-2 bg-yellow-100 text-yellow-800 rounded-md"><strong>Impact Message:</strong> {{scene.socialImpactMessage}}</p>
                    </div>
                  }
                </div>
              </div>
            }
            @if (activeTab() === 'vision') {
               <div>
                <h2 class="text-2xl font-bold text-nexus-dark mb-4">Our Vision for the Future</h2>
                <p class="text-lg leading-relaxed text-gray-700">{{ data.nextGenerationVision }}</p>
               </div>
            }
          </div>
        </div>
      }
    </div>
  `,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    @keyframes fade-in {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .animate-fade-in {
      animation: fade-in 0.5s ease-out forwards;
    }
  `]
})
export class DishStoryComponent {
  dishName = input.required<string>();
  private geminiService = inject(GeminiService);

  story = signal<DishStory | null>(null);
  isLoading = signal<boolean>(true);
  error = signal<string | null>(null);
  activeTab = signal<Tab>('ingredients');
  selectedIngredient = signal<Ingredient | null>(null);

  tabs: {id: Tab, name: string}[] = [
    {id: 'ingredients', name: 'Ingredients'},
    {id: 'workers', name: 'Workers'},
    {id: 'health', name: 'Health & Society'},
    {id: 'prep', name: 'Preparation'},
    {id: 'video', name: 'Video Journey'},
    {id: 'vision', name: 'Our Vision'},
  ];

  constructor() {
    effect(async () => {
      const name = this.dishName();
      if (name) {
        this.isLoading.set(true);
        this.error.set(null);
        this.story.set(null);
        this.activeTab.set('ingredients');
        this.selectedIngredient.set(null);
        try {
          const result = await this.geminiService.generateDishStory(name);
          this.story.set(result);
        } catch (e: any) {
          this.error.set(e.message);
        } finally {
          this.isLoading.set(false);
        }
      }
    }, { allowSignalWrites: true });
  }

  toggleIngredientDetails(ingredient: Ingredient) {
    if (this.selectedIngredient() === ingredient) {
      this.selectedIngredient.set(null);
    } else {
      this.selectedIngredient.set(ingredient);
    }
  }
}
