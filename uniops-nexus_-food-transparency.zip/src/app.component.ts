import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DishSelectorComponent } from './components/dish-selector/dish-selector.component';
import { DishStoryComponent } from './components/dish-story/dish-story.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [],
  imports: [CommonModule, DishSelectorComponent, DishStoryComponent],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent {
  selectedDish = signal<string | null>(null);

  onDishSelected(dishName: string) {
    this.selectedDish.set(dishName);
  }

  goBack() {
    this.selectedDish.set(null);
  }
}
