
import React, { useState, useEffect } from 'react';
import { fetchDishDetails } from './geminiService';
import { DishData, AppView } from './types';
import DishCard from './components/DishCard';
import DishDetail from './components/DishDetail';
import { Search, Info, Leaf, Heart, ArrowLeft, Loader2 } from 'lucide-react';

const FEATURED_DISHES = [
  "Masala Dosa",
  "Paneer Butter Masala",
  "Biryani",
  "Dal Makhani",
  "Hyderabadi Haleem"
];

function App() {
  const [view, setView] = useState<AppView>('home');
  const [selectedDish, setSelectedDish] = useState<DishData | null>(null);
  const [loadingMsg, setLoadingMsg] = useState('Connecting to UniOps Nexus...');
  const [searchTerm, setSearchTerm] = useState('');

  const handleDishClick = async (dishName: string) => {
    setView('loading');
    setLoadingMsg(`Tracing the origin of ${dishName}...`);
    try {
      const data = await fetchDishDetails(dishName);
      setSelectedDish(data);
      setView('detail');
    } catch (error) {
      console.error(error);
      alert("Failed to fetch transparency data. Please try again.");
      setView('home');
    }
  };

  const handleBack = () => {
    setView('home');
    setSelectedDish(null);
  };

  const filteredDishes = FEATURED_DISHES.filter(d => 
    d.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col font-sans">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div 
            className="flex items-center gap-2 cursor-pointer group" 
            onClick={handleBack}
          >
            <div className="bg-emerald-600 p-1.5 rounded-lg text-white group-hover:bg-emerald-700 transition-colors">
              <Leaf size={24} />
            </div>
            <span className="font-bold text-xl tracking-tight text-stone-800">UniOps <span className="text-emerald-600 font-black">Nexus</span></span>
          </div>
          
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-stone-600">
            <a href="#" className="hover:text-emerald-600 transition-colors">How it Works</a>
            <a href="#" className="hover:text-emerald-600 transition-colors">Our Vision</a>
            <a href="#" className="hover:text-emerald-600 transition-colors">Support Workers</a>
          </div>

          <div className="flex items-center gap-4">
             {view === 'detail' && (
                <button 
                  onClick={handleBack}
                  className="p-2 hover:bg-stone-100 rounded-full text-stone-600"
                >
                  <ArrowLeft size={20} />
                </button>
             )}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1">
        {view === 'home' && (
          <div className="max-w-7xl mx-auto px-4 py-12">
            <header className="mb-12 text-center">
              <h1 className="text-4xl md:text-6xl font-black text-stone-900 mb-6 leading-tight">
                Trace Every Bite. <br/>
                <span className="text-emerald-600 italic">Empower Every Worker.</span>
              </h1>
              <p className="text-lg text-stone-600 max-w-2xl mx-auto mb-8">
                UniOps Nexus is a radical transparency platform. We believe you should know the story, 
                the farm, and the hands that prepared your food.
              </p>
              
              <div className="relative max-w-xl mx-auto">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={20} />
                <input 
                  type="text" 
                  placeholder="What are you eating today? e.g. Masala Dosa" 
                  className="w-full pl-12 pr-4 py-4 rounded-2xl bg-white border border-stone-200 shadow-sm focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all text-lg"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleDishClick(searchTerm)}
                />
              </div>
            </header>

            <section>
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-bold text-stone-800">Explore Featured Dishes</h2>
                <div className="flex gap-2">
                  <span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold uppercase tracking-wider">Transparent</span>
                  <span className="px-3 py-1 bg-stone-100 text-stone-600 rounded-full text-xs font-bold uppercase tracking-wider">Verified</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredDishes.length > 0 ? (
                  filteredDishes.map((dish) => (
                    <DishCard key={dish} name={dish} onClick={() => handleDishClick(dish)} />
                  ))
                ) : (
                  <div className="col-span-full text-center py-20 bg-white rounded-3xl border-2 border-dashed border-stone-200">
                    <p className="text-stone-500 mb-4">Haven't verified "{searchTerm}" yet? We can trace it now.</p>
                    <button 
                      onClick={() => handleDishClick(searchTerm)}
                      className="px-8 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200"
                    >
                      Initialize Nexus Trace
                    </button>
                  </div>
                )}
              </div>
            </section>
          </div>
        )}

        {view === 'loading' && (
          <div className="fixed inset-0 bg-white z-[60] flex flex-col items-center justify-center text-center px-4">
            <Loader2 className="w-16 h-16 text-emerald-600 animate-spin mb-6" />
            <h2 className="text-3xl font-bold text-stone-800 mb-2">{loadingMsg}</h2>
            <p className="text-stone-500 max-w-md">Our system is fetching satellite data, farm records, and worker pay-slips to give you a complete picture.</p>
            
            <div className="mt-12 w-full max-w-sm h-1.5 bg-stone-100 rounded-full overflow-hidden">
               <div className="h-full bg-emerald-600 animate-[loading_2s_ease-in-out_infinite]" />
            </div>
            <style>{`
              @keyframes loading {
                0% { width: 0%; transform: translateX(-100%); }
                50% { width: 100%; transform: translateX(0%); }
                100% { width: 0%; transform: translateX(100%); }
              }
            `}</style>
          </div>
        )}

        {view === 'detail' && selectedDish && (
          <DishDetail dish={selectedDish} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-stone-900 text-stone-400 py-12 px-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex flex-col items-center md:items-start gap-2">
            <div className="flex items-center gap-2">
              <Leaf size={24} className="text-emerald-500" />
              <span className="text-white font-bold text-lg">UniOps Nexus</span>
            </div>
            <p className="text-sm max-w-xs text-center md:text-left">Building a next-generation food system for a healthier, fairer world.</p>
          </div>
          <div className="flex gap-8 text-sm">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Contact</a>
            <a href="#" className="hover:text-white transition-colors">API</a>
          </div>
          <div className="text-xs text-stone-600">
            © 2024 UniOps Nexus. Empowering local economies.
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
