
import React from 'react';
import { DishData } from '../types';
import { Award, Briefcase, Zap, Heart, IndianRupee, HandCoins, Users } from 'lucide-react';

interface WorkerInsightsProps {
  data: DishData['workerEmpowerment'];
}

const WorkerInsights: React.FC<WorkerInsightsProps> = ({ data }) => {
  return (
    <div className="max-w-6xl mx-auto space-y-24">
      <header className="text-center space-y-4">
        <span className="text-emerald-500 font-black uppercase tracking-widest text-sm block">Chapter 2: The Human Hands</span>
        <h2 className="text-6xl font-black text-stone-900 tracking-tighter">Worker Empowerment</h2>
        <p className="text-xl text-stone-600 max-w-2xl mx-auto leading-relaxed">
          Behind every flavor is a human story. We measure success not just in taste, but in the self-respect and prosperity of our workers.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {data.insights.map((worker, idx) => (
          <div key={idx} className="group bg-white p-10 rounded-[3.5rem] border border-stone-100 shadow-sm hover:shadow-2xl transition-all duration-500 flex flex-col h-full">
            <div className="flex items-center gap-6 mb-8">
              <div className="w-20 h-20 bg-stone-50 rounded-[2rem] flex items-center justify-center shrink-0 group-hover:bg-stone-900 transition-colors duration-500">
                <Users size={32} className="text-stone-300 group-hover:text-emerald-400" />
              </div>
              <div>
                <h3 className="text-3xl font-black text-stone-900 group-hover:text-emerald-600 transition-colors">{worker.role}</h3>
                <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full uppercase tracking-widest">{worker.wages} Earned</span>
              </div>
            </div>
            
            <div className="space-y-6 flex-1">
              <div className="bg-stone-50 p-6 rounded-3xl border border-stone-100">
                <h5 className="text-[10px] font-black text-stone-400 uppercase tracking-[0.2em] mb-3">The Contribution</h5>
                <p className="text-lg text-stone-700 italic leading-snug">"{worker.contribution}"</p>
              </div>
              
              <div className="grid grid-cols-1 gap-4">
                 <div className="flex gap-4 items-start">
                    <div className="w-2 h-2 rounded-full bg-rose-400 mt-2 shrink-0" />
                    <p className="text-sm text-stone-500 leading-relaxed"><span className="font-bold text-stone-800">Challenge:</span> {worker.challenges}</p>
                 </div>
                 <div className="flex gap-4 items-start">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 mt-2 shrink-0" />
                    <p className="text-sm text-stone-800 font-medium leading-relaxed"><span className="font-bold text-emerald-600">Progress:</span> {worker.improvementThroughTransparency}</p>
                 </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-stone-900 rounded-[4rem] p-12 md:p-24 text-white overflow-hidden relative shadow-3xl">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-500/10 rounded-full -mr-64 -mt-64 blur-[100px]" />
        
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-20">
          <div className="lg:col-span-7 space-y-12">
            <div className="space-y-6">
              <div className="flex items-center gap-4 text-emerald-400">
                <Award size={40} />
                <h3 className="text-4xl font-black">Dignity of Labor</h3>
              </div>
              <p className="text-xl text-stone-400 leading-relaxed font-light">{data.dignityOfLabor}</p>
            </div>

            <div className="space-y-6 pt-12 border-t border-white/10">
              <div className="flex items-center gap-4 text-rose-400">
                <Zap size={40} />
                <h3 className="text-4xl font-black">The Textile Parallel</h3>
              </div>
              <p className="text-xl text-stone-400 leading-relaxed font-light">
                <span className="block mb-4 p-6 bg-white/5 rounded-3xl border border-white/10 text-stone-300 italic">
                  Similar to the cotton weavers of the South and the silk saree masters, our food workers face the same cycle of invisibility.
                </span>
                {data.textileParallel}
              </p>
            </div>
          </div>

          <div className="lg:col-span-5 space-y-8">
            <div className="bg-white/5 backdrop-blur-3xl p-10 rounded-[3.5rem] border border-white/10 h-full flex flex-col justify-center text-center">
              <div className="w-24 h-24 bg-emerald-500 rounded-full mx-auto flex items-center justify-center mb-10 shadow-2xl shadow-emerald-500/20">
                <HandCoins size={40} className="text-white" />
              </div>
              <h4 className="text-3xl font-black mb-6 leading-tight">Economic Fairness</h4>
              <p className="text-stone-400 text-lg leading-relaxed mb-12 italic">
                "{data.profitExpenseImpact}"
              </p>
              
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-emerald-400 mb-2">
                  <span>Transparency Gap Closed</span>
                  <span>92%</span>
                </div>
                <div className="h-4 bg-stone-800 rounded-full overflow-hidden p-1">
                   <div className="w-[92%] h-full bg-emerald-500 rounded-full shadow-[0_0_20px_rgba(16,185,129,0.4)]" />
                </div>
              </div>
              
              <p className="mt-8 text-xs text-stone-500 font-medium">Verified by UniOps Labor Audit</p>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center py-12">
         <button className="px-12 py-6 bg-emerald-600 text-white rounded-[2rem] font-black text-xl hover:bg-emerald-700 hover:scale-105 transition-all shadow-2xl shadow-emerald-200">
           Support Fair Wages Foundation
         </button>
      </div>
    </div>
  );
};

export default WorkerInsights;
