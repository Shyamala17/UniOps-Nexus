
import React, { useState } from 'react';
import { DishData, Ingredient } from '../types';
import { 
  Users, 
  Clock, 
  MapPin, 
  HeartPulse, 
  PlayCircle, 
  Eye, 
  Sparkles,
  ChevronRight,
  TrendingUp,
  History,
  Info,
  ChevronLeft
} from 'lucide-react';
import IngredientJourney from './IngredientJourney';
import WorkerInsights from './WorkerInsights';
import NextGenVision from './NextGenVision';

interface DishDetailProps {
  dish: DishData;
}

const DishDetail: React.FC<DishDetailProps> = ({ dish }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [selectedIngredient, setSelectedIngredient] = useState<Ingredient | null>(null);

  const steps = [
    { label: "Ingredients", icon: MapPin },
    { label: "Workers", icon: Users },
    { label: "Health & Society", icon: HeartPulse },
    { label: "Preparation", icon: Clock },
    { label: "Video Journey", icon: PlayCircle },
    { label: "Vision", icon: Sparkles },
  ];

  const handleNext = () => setActiveStep(prev => Math.min(prev + 1, steps.length - 1));
  const handleBack = () => setActiveStep(prev => Math.max(prev - 1, 0));

  return (
    <div className="bg-stone-50 min-h-screen pb-24">
      {/* Hero Header */}
      <div className="relative h-[50vh] w-full overflow-hidden bg-stone-900">
        <img 
          src={`https://picsum.photos/seed/${dish.name}/1200/800`} 
          className="w-full h-full object-cover opacity-60"
          alt={dish.name}
        />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white px-4 text-center">
          <div className="bg-emerald-500 text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-[0.2em] mb-6 animate-bounce">
            Revealing the Hidden Story
          </div>
          <h1 className="text-5xl md:text-7xl font-black mb-6 tracking-tighter drop-shadow-2xl">{dish.name}</h1>
          <p className="text-xl md:text-2xl text-stone-200 max-w-2xl font-light italic opacity-90 leading-relaxed">
            "{dish.description}"
          </p>
        </div>
        <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-stone-50 to-transparent" />
      </div>

      {/* Narrative Progress Bar */}
      <div className="sticky top-16 z-40 bg-white/90 backdrop-blur-xl border-b border-stone-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex-1 flex items-center gap-1 md:gap-4 overflow-x-auto no-scrollbar">
              {steps.map((step, idx) => (
                <button
                  key={step.label}
                  onClick={() => setActiveStep(idx)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all whitespace-nowrap ${
                    activeStep === idx 
                    ? "bg-stone-900 text-white shadow-lg" 
                    : activeStep > idx ? "text-emerald-600 font-bold" : "text-stone-400 hover:text-stone-600"
                  }`}
                >
                  <span className={`w-5 h-5 flex items-center justify-center rounded-full text-[10px] ${activeStep >= idx ? "bg-emerald-500" : "bg-stone-200"}`}>
                    {idx + 1}
                  </span>
                  <span className="text-xs font-bold uppercase tracking-wider hidden md:inline">{step.label}</span>
                  <step.icon size={14} className="md:hidden" />
                </button>
              ))}
            </div>
            <div className="ml-4 flex items-center gap-2">
               <button onClick={handleBack} disabled={activeStep === 0} className="p-2 disabled:opacity-30 text-stone-400 hover:text-stone-900"><ChevronLeft/></button>
               <button onClick={handleNext} disabled={activeStep === steps.length - 1} className="p-2 disabled:opacity-30 text-stone-400 hover:text-stone-900"><ChevronRight/></button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Step 1 & 6: Ingredient Transparency & Demo */}
        {activeStep === 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 animate-in fade-in slide-in-from-bottom-8 duration-700">
            <div className="lg:col-span-4 space-y-8">
              <div>
                <h2 className="text-4xl font-black text-stone-900 mb-4">The DNA of {dish.name}</h2>
                <p className="text-stone-600 leading-relaxed">
                  Every bite contains a history. We've mapped every gram back to its source. 
                  <span className="block mt-4 text-emerald-600 font-bold italic">Click an ingredient below to reveal its full journey.</span>
                </p>
              </div>
              
              <div className="grid grid-cols-1 gap-3">
                {dish.ingredients.map((ing, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedIngredient(ing)}
                    className={`w-full text-left p-6 rounded-3xl border-2 transition-all flex items-center justify-between group ${
                      selectedIngredient?.name === ing.name 
                      ? "bg-white border-emerald-500 shadow-xl -translate-y-1" 
                      : "bg-white border-stone-100 hover:border-emerald-200 hover:shadow-md"
                    }`}
                  >
                    <div>
                      <h4 className="font-black text-stone-800 text-lg">{ing.name}</h4>
                      <p className="text-xs text-stone-500 font-medium uppercase tracking-widest">{ing.origin.district}, {ing.origin.state}</p>
                    </div>
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${selectedIngredient?.name === ing.name ? "bg-emerald-500 text-white" : "bg-stone-50 text-stone-300 group-hover:bg-emerald-50 group-hover:text-emerald-400"}`}>
                       <ChevronRight size={20} />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="lg:col-span-8">
              {selectedIngredient ? (
                <IngredientJourney ingredient={selectedIngredient} />
              ) : (
                <div className="h-full min-h-[500px] flex flex-col items-center justify-center bg-white rounded-[3rem] border-4 border-dashed border-stone-100 text-stone-300 p-12 text-center group cursor-pointer hover:border-emerald-100 transition-colors" onClick={() => setSelectedIngredient(dish.ingredients[0])}>
                  <div className="relative mb-8">
                     <div className="absolute inset-0 bg-emerald-400 rounded-full blur-2xl opacity-20 group-hover:opacity-40 transition-opacity" />
                     <div className="relative bg-white p-10 rounded-full shadow-inner">
                        <Eye size={64} className="text-stone-200 group-hover:text-emerald-500 transition-colors" />
                     </div>
                  </div>
                  <h3 className="text-3xl font-black text-stone-800 mb-4">Chapter 1: The Source</h3>
                  <p className="max-w-md text-stone-500 text-lg leading-relaxed">
                    Choose an ingredient to begin the "Click-to-Know" journey. Reveal origin, farmer wages, and the labor required for every piece.
                  </p>
                  <div className="mt-8 flex items-center gap-2 text-emerald-600 font-black animate-pulse">
                    Select Ingredient <ChevronRight size={18}/>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Step 2: Worker Empowerment */}
        {activeStep === 1 && (
          <div className="animate-in fade-in slide-in-from-right-8 duration-700">
            <WorkerInsights data={dish.workerEmpowerment} />
          </div>
        )}

        {/* Step 3: Health & Society */}
        {activeStep === 2 && (
          <div className="max-w-5xl mx-auto space-y-16 animate-in fade-in slide-in-from-bottom-8 duration-700">
            <div className="text-center">
              <span className="text-rose-500 font-black uppercase tracking-widest text-sm block mb-4">Chapter 3: Health & Community</span>
              <h2 className="text-5xl font-black text-stone-900 mb-6">Social Nutrition Analysis</h2>
              <p className="text-xl text-stone-600 max-w-3xl mx-auto leading-relaxed">How this meal intersects with health equity, middle-class budgets, and the future of community nutrition.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-stone-100 hover:shadow-xl transition-all group">
                <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform">
                  <History size={32} />
                </div>
                <h3 className="text-2xl font-bold text-stone-800 mb-4">Traditional vs. Industrial</h3>
                <p className="text-stone-600 leading-relaxed">{dish.healthSocietyAnalysis.comparison}</p>
              </div>

              <div className="bg-white p-10 rounded-[3rem] shadow-sm border border-stone-100 hover:shadow-xl transition-all group">
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform">
                  <HeartPulse size={32} />
                </div>
                <h3 className="text-2xl font-bold text-stone-800 mb-4">Health Benefits</h3>
                <p className="text-stone-600 leading-relaxed">{dish.healthSocietyAnalysis.benefits}</p>
              </div>

              <div className="bg-stone-900 p-10 rounded-[3rem] text-white md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
                 <div>
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-rose-500 text-white text-[10px] font-black uppercase rounded-full mb-6">Economic Struggle</div>
                    <h3 className="text-3xl font-bold mb-4">Middle-Class & Poor Family Impact</h3>
                    <p className="text-stone-400 leading-relaxed mb-6">{dish.healthSocietyAnalysis.middleClassImpact}</p>
                    <div className="p-6 bg-white/5 rounded-3xl border border-white/10">
                       <p className="text-sm font-medium italic text-stone-300">"{dish.healthSocietyAnalysis.affordabilityStruggle}"</p>
                    </div>
                 </div>
                 <div className="space-y-6">
                    <div className="bg-emerald-500/10 border border-emerald-500/20 p-8 rounded-[2rem]">
                       <h4 className="text-xl font-bold text-emerald-400 mb-4 flex items-center gap-2">
                         <Sparkles size={20} /> Generational Health
                       </h4>
                       <p className="text-stone-300 text-sm leading-relaxed">{dish.healthSocietyAnalysis.generationalHealth}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                       <div className="bg-white/5 p-4 rounded-2xl border border-white/5 text-center">
                          <span className="text-2xl font-black block">Baby</span>
                          <span className="text-[10px] text-stone-500 uppercase tracking-widest">Nutrition Focus</span>
                       </div>
                       <div className="bg-white/5 p-4 rounded-2xl border border-white/5 text-center">
                          <span className="text-2xl font-black block">Milk</span>
                          <span className="text-[10px] text-stone-500 uppercase tracking-widest">Health Standards</span>
                       </div>
                    </div>
                 </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Preparation Steps */}
        {activeStep === 3 && (
          <div className="max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-700">
             <div className="text-center mb-16">
              <span className="text-indigo-500 font-black uppercase tracking-widest text-sm block mb-4">Chapter 4: The Kitchen Craft</span>
              <h2 className="text-5xl font-black text-stone-900 mb-4">Step-by-Step Preparation</h2>
              <p className="text-xl text-stone-600 italic">Crafted over <span className="text-stone-900 font-black">{dish.preparation.totalDuration}</span> of focused labor.</p>
            </div>

            <div className="relative space-y-12">
              <div className="absolute left-6 md:left-1/2 top-4 bottom-4 w-1 bg-stone-200 -translate-x-1/2 hidden md:block" />
              
              {dish.preparation.steps.map((step, idx) => (
                <div key={idx} className={`relative flex flex-col md:flex-row gap-8 items-start md:items-center ${idx % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}>
                  <div className="z-10 w-12 h-12 rounded-full bg-stone-900 text-white flex items-center justify-center font-black text-xl shrink-0 shadow-xl border-4 border-white md:absolute md:left-1/2 md:-translate-x-1/2">
                    {idx + 1}
                  </div>
                  <div className={`flex-1 w-full bg-white p-8 rounded-[2.5rem] shadow-sm border border-stone-100 transition-all hover:shadow-xl ${idx % 2 === 0 ? "md:text-right" : "md:text-left"}`}>
                    <div className={`flex flex-col mb-4 ${idx % 2 === 0 ? "md:items-end" : "md:items-start"}`}>
                       <span className="text-xs font-black text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full uppercase mb-2">{step.duration}</span>
                       <h4 className="text-2xl font-bold text-stone-800 leading-tight">{step.instruction}</h4>
                    </div>
                    <div className={`flex flex-wrap gap-4 text-sm text-stone-500 ${idx % 2 === 0 ? "md:justify-end" : "md:justify-start"}`}>
                      <span className="flex items-center gap-1.5 bg-stone-50 px-3 py-1.5 rounded-xl font-medium"><Sparkles size={14} className="text-amber-500"/> {step.quantity}</span>
                      <span className="flex items-center gap-1.5 bg-stone-50 px-3 py-1.5 rounded-xl font-medium"><History size={14} className="text-blue-500"/> {step.tool}</span>
                    </div>
                  </div>
                  <div className="flex-1 hidden md:block" />
                </div>
              ))}
            </div>

            <div className="mt-20 p-12 bg-indigo-900 rounded-[3rem] text-white shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 right-0 p-8 opacity-10">
                  <Clock size={120} />
               </div>
               <h3 className="text-3xl font-black mb-6">Home Cooking vs. Commercial Realities</h3>
               <p className="text-indigo-200 text-lg leading-relaxed italic max-w-3xl">
                 {dish.preparation.homeVsHotel}
               </p>
               <div className="mt-10 grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-white/10 p-4 rounded-2xl text-center">
                    <span className="block text-xs uppercase opacity-60 mb-1">Modern Tool</span>
                    <span className="font-bold">Air Fryers</span>
                  </div>
                  <div className="bg-white/10 p-4 rounded-2xl text-center">
                    <span className="block text-xs uppercase opacity-60 mb-1">Traditional</span>
                    <span className="font-bold">Clay Pots</span>
                  </div>
                  <div className="bg-white/10 p-4 rounded-2xl text-center">
                    <span className="block text-xs uppercase opacity-60 mb-1">Commercial</span>
                    <span className="font-bold">Steam Jackets</span>
                  </div>
                  <div className="bg-white/10 p-4 rounded-2xl text-center">
                    <span className="block text-xs uppercase opacity-60 mb-1">Labor Type</span>
                    <span className="font-bold">Manual</span>
                  </div>
               </div>
            </div>
          </div>
        )}

        {/* Step 5: Video Script Simulation */}
        {activeStep === 4 && (
          <div className="max-w-6xl mx-auto animate-in fade-in slide-in-from-right-8 duration-700">
            <div className="text-center mb-20">
              <span className="text-purple-600 font-black uppercase tracking-widest text-sm block mb-4">Chapter 5: Cinematic Journey</span>
              <h2 className="text-5xl font-black text-stone-900 mb-6">Farm-to-Plate: The Documentary</h2>
              <p className="text-xl text-stone-600">A visual script capturing the effort, the distance, and the impact of every worker.</p>
            </div>

            <div className="space-y-16">
              {dish.videoScript.map((scene, idx) => (
                <div key={idx} className={`flex flex-col md:flex-row gap-12 items-center ${idx % 2 === 0 ? "" : "md:flex-row-reverse"}`}>
                   <div className="flex-1 w-full aspect-video rounded-[3rem] overflow-hidden shadow-2xl group relative bg-stone-900">
                      <img 
                        src={`https://picsum.photos/seed/${scene.title}/900/600`} 
                        className="w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-1000"
                        alt={scene.title}
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                         <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/30 group-hover:bg-purple-600 transition-colors">
                            <PlayCircle size={32} className="text-white" />
                         </div>
                      </div>
                      <div className="absolute top-6 left-6 bg-purple-600 text-white text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-lg">
                        Scene {idx + 1}
                      </div>
                   </div>
                   <div className="flex-1 space-y-6">
                      <div className="flex items-center gap-3">
                         <span className="w-12 h-1 w-purple-600 rounded-full" />
                         <span className="text-purple-600 font-black uppercase text-xs tracking-widest">{scene.duration} Sequence</span>
                      </div>
                      <h3 className="text-4xl font-black text-stone-900">{scene.title}</h3>
                      <p className="text-lg text-stone-600 leading-relaxed font-light">{scene.visuals}</p>
                      <div className="bg-stone-100 p-8 rounded-[2rem] border-l-8 border-purple-500">
                         <p className="text-stone-400 text-[10px] font-black uppercase tracking-widest mb-2">Social Impact Message</p>
                         <p className="text-xl font-bold text-stone-800 italic leading-snug">"{scene.message}"</p>
                      </div>
                   </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Step 7: Next-Generation Vision */}
        {activeStep === 5 && (
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
             <NextGenVision vision={dish.vision} />
          </div>
        )}
      </div>

      {/* Floating Action Navigation */}
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-4 bg-white/90 backdrop-blur-xl px-6 py-4 rounded-3xl shadow-2xl border border-stone-200">
         <button 
           onClick={handleBack} 
           disabled={activeStep === 0}
           className="flex items-center gap-2 font-bold text-stone-400 hover:text-stone-900 disabled:opacity-30 transition-colors px-4 py-2"
         >
           <ChevronLeft size={20}/> Previous Chapter
         </button>
         <div className="w-px h-8 bg-stone-200" />
         <button 
           onClick={handleNext}
           disabled={activeStep === steps.length - 1}
           className="flex items-center gap-2 font-black text-emerald-600 hover:text-emerald-700 disabled:opacity-30 transition-colors px-4 py-2"
         >
           {activeStep === steps.length - 1 ? "Vision Complete" : "Continue Story"} <ChevronRight size={20}/>
         </button>
      </div>
    </div>
  );
};

export default DishDetail;
