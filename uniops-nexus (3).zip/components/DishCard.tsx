
import React from 'react';

interface DishCardProps {
  name: string;
  onClick: () => void;
}

const DishCard: React.FC<DishCardProps> = ({ name, onClick }) => {
  // Use a deterministic placeholder image based on name
  const imageUrl = `https://picsum.photos/seed/${name}/800/600`;

  return (
    <div 
      className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-stone-100 cursor-pointer transform hover:-translate-y-1"
      onClick={onClick}
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img 
          src={imageUrl} 
          alt={name} 
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4">
           <span className="px-3 py-1 bg-white/90 backdrop-blur rounded-full text-xs font-bold shadow-sm">Verified Trace</span>
        </div>
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold text-stone-800 mb-2 group-hover:text-emerald-600 transition-colors">{name}</h3>
        <p className="text-sm text-stone-500 mb-4 line-clamp-2">Click to see the complete journey from the farm to your plate, including worker insights.</p>
        <div className="flex items-center justify-between text-xs font-medium text-emerald-600 uppercase tracking-tighter">
          <span>12 Workers Involved</span>
          <span>4 Farms Traced</span>
        </div>
      </div>
    </div>
  );
};

export default DishCard;
