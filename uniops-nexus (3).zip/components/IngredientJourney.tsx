
import React from 'react';
import { Ingredient } from '../types';
import { User, MapPin, Package, Wrench, BadgeCheck, CircleAlert, IndianRupee, Clock, ArrowDown, TrendingUp } from 'lucide-react';

interface IngredientJourneyProps {
  ingredient: Ingredient;
}

const IngredientJourney: React.FC<IngredientJourneyProps> = ({ ingredient }) => {
  return (
    <div className="bg-white p-8 md:p-16 rounded-[4rem] shadow-2xl border border-stone-100 animate-in fade-in zoom-in duration-700 relative overflow-hidden">
      {/* Decorative Accent */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-50 rounded-full -mr-32 -mt-32 blur-3xl opacity-60" />

      <div className="flex flex-col md:flex-row items-center gap-12 mb-16 relative z-10">
        <div className="w-48 h-48 rounded-[3rem] overflow-hidden shadow-2xl shrink-0 border-4 border-white rotate-3 hover:rotate-0 transition-transform duration-500">
          <img 
            src={`https://picsum.photos/seed/${ingredient.name}/400/400`} 
            alt={ingredient.name}
            className="w-full h-full object-cover scale-110"
          />
        </div>
        <div className="text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
            <span className="bg-emerald-100 text-emerald-700 px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">Authenticated Trace</span>
            <BadgeCheck className="text-emerald-500" size={24} />
          </div>
          <h2 className="text-5xl font-black text-stone-900 mb-2 leading-tight">{ingredient.name}</h2>
          <p className="text-stone-400 font-mono text-sm tracking-tighter">BLOCKCHAIN-ID: NEX-{Math.floor(Math.random() * 9000000) + 1000000}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 relative z-10">
        <section className="space-y-12">
          {/* Step 1: The Land */}
          <div className="flex gap-6 group">
            <div className="w-14 h-14 bg-amber-50 text-amber-600 rounded-[1.5rem] flex items-center justify-center shrink-0 shadow-sm group-hover:bg-amber-500 group-hover:text-white transition-colors">
              <MapPin size={28} />
            </div>
            <div>
              <h4 className="font-black text-stone-900 text-xl mb-2">The Land & Ownership</h4>
              <p className="text-stone-600 text-lg leading-relaxed">
                Nurtured at <span className="font-black text-stone-800 underline decoration-amber-300 decoration-4">{ingredient.origin.farm}</span>. 
                Owner: <span className="italic">{ingredient.origin.owner}</span>.
                <span className="block mt-1 text-sm text-stone-400 font-bold uppercase tracking-wider">{ingredient.origin.district}, {ingredient.origin.state}</span>
              </p>
            </div>
          </div>

          {/* Step 2: The Hands */}
          <div className="flex gap-6 group">
            <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-[1.5rem] flex items-center justify-center shrink-0 shadow-sm group-hover:bg-emerald-500 group-hover:text-white transition-colors">
              <User size={28} />
            </div>
            <div>
              <h4 className="font-black text-stone-900 text-xl mb-2">The Farmer's Life</h4>
              <p className="text-stone-600 text-lg leading-relaxed">
                Hand-picked by <span className="font-black text-stone-800">{ingredient.farmer.name}</span> ({ingredient.farmer.age} yrs). 
                Daily effort: <span className="font-bold">{ingredient.farmer.workingHours}</span> of intensive labor.
              </p>
              <div className="mt-4 p-4 bg-stone-50 rounded-2xl border border-stone-100 text-sm italic text-stone-500 border-l-4 border-emerald-500">
                "{ingredient.farmer.background}"
              </div>
            </div>
          </div>

          {/* Step 3: The Method */}
          <div className="flex gap-6 group">
            <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-[1.5rem] flex items-center justify-center shrink-0 shadow-sm group-hover:bg-blue-500 group-hover:text-white transition-colors">
              <Wrench size={28} />
            </div>
            <div>
              <h4 className="font-black text-stone-900 text-xl mb-2">Production Ethics</h4>
              <p className="text-stone-600 text-lg leading-relaxed">
                Produced via <span className="font-black text-stone-800">{ingredient.productionMethod}</span> methods. 
                Yield: <span className="font-bold text-blue-600">{ingredient.quantityProduced}</span> this harvest.
              </p>
            </div>
          </div>
        </section>

        <section className="space-y-8">
           <div className="bg-stone-900 p-10 rounded-[3rem] text-white shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-6 opacity-10">
                 <IndianRupee size={80} />
              </div>
              <div className="flex items-center gap-3 mb-8">
                <TrendingUp size={20} className="text-emerald-400" />
                <h4 className="font-bold text-stone-400 uppercase tracking-[0.2em] text-xs">Direct Economic Impact</h4>
              </div>
              
              <div className="space-y-6">
                <div className="p-6 bg-white/5 rounded-3xl border border-white/10">
                  <p className="text-xs text-stone-500 font-bold uppercase mb-2">Farmer Wage per unit</p>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-black text-emerald-400">{ingredient.wagePerUnit}</span>
                    <span className="text-stone-500 font-medium">INR</span>
                  </div>
                </div>
                <div className="p-6 bg-white/5 rounded-3xl border border-white/10">
                  <p className="text-xs text-stone-500 font-bold uppercase mb-2">Total Quantity Used</p>
                  <p className="text-2xl font-black">{ingredient.quantity}</p>
                </div>
              </div>
           </div>

           <div className="bg-rose-50 p-10 rounded-[3rem] border border-rose-100 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:scale-125 transition-transform duration-700">
                <CircleAlert size={60} className="text-rose-500" />
              </div>
              <h4 className="font-black text-rose-900 text-xl mb-4">Critical Challenges</h4>
              <p className="text-rose-800 text-lg leading-relaxed font-medium">
                "{ingredient.challenges}"
              </p>
              <div className="mt-6 flex items-center gap-2 text-rose-600 font-bold text-sm">
                 <Clock size={16}/> Resolution status: Active
              </div>
           </div>
        </section>
      </div>

      <div className="mt-20 pt-12 border-t border-stone-100 flex flex-col md:flex-row items-center justify-between gap-8 relative z-10">
        <div className="flex gap-12">
           <div className="text-center">
              <span className="block text-4xl font-black text-stone-900">100%</span>
              <span className="text-[10px] text-stone-400 font-black uppercase tracking-widest">Transparency Score</span>
           </div>
           <div className="w-px h-12 bg-stone-200 self-center hidden md:block" />
           <div className="text-center">
              <span className="block text-4xl font-black text-stone-900">9.2</span>
              <span className="text-[10px] text-stone-400 font-black uppercase tracking-widest">Sustainability Index</span>
           </div>
        </div>
        <button className="w-full md:w-auto px-10 py-5 bg-stone-900 text-white rounded-3xl font-black text-lg hover:bg-stone-800 transition-all hover:shadow-2xl active:scale-95 flex items-center justify-center gap-3">
          Download PDF Audit <ArrowDown size={20} />
        </button>
      </div>
    </div>
  );
};

export default IngredientJourney;
