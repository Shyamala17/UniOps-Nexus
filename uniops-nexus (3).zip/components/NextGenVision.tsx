
import React from 'react';
import { Sparkles, ArrowRight, ShieldCheck, Globe, Users } from 'lucide-react';

interface NextGenVisionProps {
  vision: string;
}

const NextGenVision: React.FC<NextGenVisionProps> = ({ vision }) => {
  return (
    <div className="max-w-5xl mx-auto py-12">
      <div className="relative bg-emerald-600 rounded-[3rem] p-8 md:p-20 text-white overflow-hidden text-center">
        {/* Background blobs */}
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-emerald-500 rounded-full mix-blend-multiply filter blur-3xl opacity-50 animate-pulse" />
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-emerald-400 rounded-full mix-blend-multiply filter blur-3xl opacity-50 animate-pulse" />

        <div className="relative z-10">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-white text-emerald-600 rounded-3xl mb-8 shadow-2xl">
            <Sparkles size={40} />
          </div>
          <h2 className="text-4xl md:text-6xl font-black mb-8">The Next-Gen Vision</h2>
          <p className="text-xl md:text-2xl text-emerald-100 font-medium leading-relaxed max-w-3xl mx-auto mb-12 italic">
            "{vision}"
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-3xl border border-white/20">
               <ShieldCheck className="mx-auto mb-4 text-emerald-200" size={32} />
               <h4 className="font-bold mb-2">Sustainable Living</h4>
               <p className="text-xs text-emerald-100/80">Regenerative farming and waste reduction in every chain.</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-3xl border border-white/20">
               <Globe className="mx-auto mb-4 text-emerald-200" size={32} />
               <h4 className="font-bold mb-2">Fair Global Markets</h4>
               <p className="text-xs text-emerald-100/80">Direct-to-consumer links that bypass unfair middlemen.</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-3xl border border-white/20">
               <Users className="mx-auto mb-4 text-emerald-200" size={32} />
               <h4 className="font-bold mb-2">Social Respect</h4>
               <p className="text-xs text-emerald-100/80">Dignity and healthcare for all manual laborers.</p>
            </div>
          </div>

          <div className="flex flex-col md:flex-row items-center justify-center gap-4">
             <button className="px-10 py-5 bg-white text-emerald-900 rounded-2xl font-black text-lg hover:scale-105 transition-transform flex items-center gap-3 shadow-xl">
               Join the Revolution <ArrowRight size={20} />
             </button>
             <button className="px-10 py-5 bg-emerald-800 text-white rounded-2xl font-black text-lg hover:bg-emerald-700 transition-colors">
               Invest in Farmers
             </button>
          </div>
        </div>
      </div>
      
      <div className="mt-20 text-center text-stone-400">
        <p className="text-sm font-medium uppercase tracking-[0.2em] mb-4">Powered by Nexus Transparency Engine v3.1</p>
        <p className="text-xs max-w-md mx-auto">Connecting 1.2M farmers with 450M consumers worldwide through real-time blockchain and AI-driven supply chain verification.</p>
      </div>
    </div>
  );
};

export default NextGenVision;
