
import { GoogleGenAI, Type } from "@google/genai";
import { DishData } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const dishSchema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING },
    description: { type: Type.STRING },
    ingredients: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          quantity: { type: Type.STRING },
          origin: {
            type: Type.OBJECT,
            properties: {
              state: { type: Type.STRING },
              district: { type: Type.STRING },
              farm: { type: Type.STRING },
              owner: { type: Type.STRING },
            },
            required: ["state", "district", "farm", "owner"]
          },
          farmer: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              age: { type: Type.NUMBER },
              workingHours: { type: Type.STRING },
              background: { type: Type.STRING },
            },
            required: ["name", "age", "workingHours", "background"]
          },
          productionMethod: { type: Type.STRING },
          quantityProduced: { type: Type.STRING },
          wagePerUnit: { type: Type.STRING },
          challenges: { type: Type.STRING },
        },
        required: ["name", "quantity", "origin", "farmer", "productionMethod", "quantityProduced", "wagePerUnit", "challenges"]
      }
    },
    workerEmpowerment: {
      type: Type.OBJECT,
      properties: {
        insights: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              role: { type: Type.STRING },
              contribution: { type: Type.STRING },
              wages: { type: Type.STRING },
              challenges: { type: Type.STRING },
              improvementThroughTransparency: { type: Type.STRING },
            },
            required: ["role", "contribution", "wages", "challenges", "improvementThroughTransparency"]
          }
        },
        textileParallel: { type: Type.STRING },
        dignityOfLabor: { type: Type.STRING },
        profitExpenseImpact: { type: Type.STRING },
      },
      required: ["insights", "textileParallel", "dignityOfLabor", "profitExpenseImpact"]
    },
    healthSocietyAnalysis: {
      type: Type.OBJECT,
      properties: {
        comparison: { type: Type.STRING },
        benefits: { type: Type.STRING },
        middleClassImpact: { type: Type.STRING },
        affordabilityStruggle: { type: Type.STRING },
        generationalHealth: { type: Type.STRING },
      },
      required: ["comparison", "benefits", "middleClassImpact", "affordabilityStruggle", "generationalHealth"]
    },
    preparation: {
      type: Type.OBJECT,
      properties: {
        steps: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              instruction: { type: Type.STRING },
              quantity: { type: Type.STRING },
              tool: { type: Type.STRING },
              duration: { type: Type.STRING },
            },
            required: ["instruction", "quantity", "tool", "duration"]
          }
        },
        totalDuration: { type: Type.STRING },
        homeVsHotel: { type: Type.STRING },
      },
      required: ["steps", "totalDuration", "homeVsHotel"]
    },
    videoScript: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          visuals: { type: Type.STRING },
          duration: { type: Type.STRING },
          message: { type: Type.STRING },
        },
        required: ["title", "visuals", "duration", "message"]
      }
    },
    vision: { type: Type.STRING },
  },
  required: ["name", "description", "ingredients", "workerEmpowerment", "healthSocietyAnalysis", "preparation", "videoScript", "vision"]
};

export async function fetchDishDetails(dishName: string): Promise<DishData> {
  const prompt = `You are UniOps Nexus, a transparent food and worker system. Generate a full transparency report for the dish "${dishName}". 
  Provide realistic data including:
  1. Ingredient origins (state, district, farm in India) and farmer backgrounds.
  2. Worker wage insights and parallels to textile weavers (cotton, silk, mats).
  3. Health comparisons (Traditional vs Modern), specific middle-class impact, and struggles of poor families (mentioning baby nutrition or health drinks where relevant).
  4. Preparation steps with exact timings (min/sec) and tools.
  5. A 4-scene video script journey (Farm -> Market -> Kitchen -> Table).
  
  The tone should be empathetic, highlighting dignity of labor and social impact. Use the provided JSON schema.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: dishSchema,
    }
  });

  return JSON.parse(response.text);
}
