
export interface Ingredient {
  name: string;
  quantity: string;
  origin: {
    state: string;
    district: string;
    farm: string;
    owner: string;
  };
  farmer: {
    name: string;
    age: number;
    workingHours: string;
    background: string;
  };
  productionMethod: 'Manual' | 'Modern' | 'Hybrid';
  quantityProduced: string;
  wagePerUnit: string;
  challenges: string;
}

export interface PrepStep {
  instruction: string;
  quantity: string;
  tool: string;
  duration: string;
}

export interface VideoScene {
  title: string;
  visuals: string;
  duration: string;
  message: string;
}

export interface WorkerInsight {
  role: string;
  contribution: string;
  wages: string;
  challenges: string;
  improvementThroughTransparency: string;
}

export interface DishData {
  name: string;
  description: string;
  ingredients: Ingredient[];
  workerEmpowerment: {
    insights: WorkerInsight[];
    textileParallel: string;
    dignityOfLabor: string;
    profitExpenseImpact: string;
  };
  healthSocietyAnalysis: {
    comparison: string;
    benefits: string;
    middleClassImpact: string;
    affordabilityStruggle: string;
    generationalHealth: string;
  };
  preparation: {
    steps: PrepStep[];
    totalDuration: string;
    homeVsHotel: string;
  };
  videoScript: VideoScene[];
  vision: string;
}

export type AppView = 'home' | 'loading' | 'detail';
