
import { ChangeDetectionStrategy, Component, signal, effect, WritableSignal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GeminiService } from './services/gemini.service';
import { DishStory, Dish } from './models/dish.model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app.component.html',
  styleUrls: [],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {
  
  dishes: Dish[] = [
    { name: 'Samosa', description: 'A popular Indian appetizer with a savory filling.', image: 'https://picsum.photos/id/1060/400/300' },
    { name: 'Butter Chicken', description: 'A creamy and flavorful curry from North India.', image: 'https://picsum.photos/id/1080/400/300' },
    { name: 'Masala Dosa', description: 'A South Indian crepe made from a fermented batter.', image: 'https://picsum.photos/id/312/400/300' }
  ];

  sections = [
    { id: 'transparency', title: 'Ingredient Transparency' },
    { id: 'empowerment', title: 'Worker Empowerment' },
    { id: 'health', title: 'Health & Society Analysis' },
    { id: 'preparation', title: 'Preparation Steps' },
    { id: 'video', title: 'Video Script Simulation' },
    { id: 'vision', title: 'Next-Generation Vision' },
    { id: 'image', title: 'Visualize the Dish' }
  ];

  selectedDish: WritableSignal<Dish | null> = signal(null);
  dishStory: WritableSignal<DishStory | null> = signal(null);
  isLoading = signal(false);
  isGeneratingImage = signal(false);
  error = signal<string | null>(null);
  generatedImage = signal<string | null>(null);
  activeSection = signal<string | null>('transparency');

  constructor(private geminiService: GeminiService) {}
  
  selectDish(dish: Dish) {
    this.selectedDish.set(dish);
    this.dishStory.set(null);
    this.generatedImage.set(null);
    this.error.set(null);
    this.isLoading.set(true);
    this.activeSection.set('transparency');

    this.geminiService.generateDishStory(dish.name)
      .then(story => {
        this.dishStory.set(story);
      })
      .catch(err => {
        console.error(err);
        this.error.set('Failed to generate the dish story. Please try again later.');
      })
      .finally(() => {
        this.isLoading.set(false);
      });
  }

  generateImage(aspectRatio: string) {
    const dishName = this.selectedDish()?.name;
    if (!dishName) return;

    this.isGeneratingImage.set(true);
    this.generatedImage.set(null);
    
    const prompt = `A delicious, professionally photographed plate of ${dishName}. appetizing, high detail, studio lighting.`;
    
    this.geminiService.generateDishImage(prompt, aspectRatio)
      .then(imageUrl => {
        this.generatedImage.set(imageUrl);
      })
      .catch(err => {
        console.error(err);
        this.error.set('Failed to generate image. The model may be unavailable.');
      })
      .finally(() => {
        this.isGeneratingImage.set(false);
      });
  }
  
  reset() {
    this.selectedDish.set(null);
    this.dishStory.set(null);
    this.isLoading.set(false);
    this.error.set(null);
    this.generatedImage.set(null);
  }

  toggleSection(sectionId: string) {
    if (this.activeSection() === sectionId) {
      this.activeSection.set(null);
    } else {
      this.activeSection.set(sectionId);
    }
  }
}
