
import { Injectable } from '@angular/core';
import { GoogleGenAI, Type } from '@google/genai';
import { DishStory } from '../models/dish.model';

@Injectable({
  providedIn: 'root'
})
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    if (!process.env.API_KEY) {
      throw new Error("API_KEY environment variable not set");
    }
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async generateDishStory(dishName: string): Promise<DishStory> {
    const prompt = `You are UniOps Nexus, a system providing deep transparency into food systems. Your task is to generate a detailed story for the dish: "${dishName}". Respond strictly in JSON format according to the provided schema. Do not include any explanatory text, markdown formatting, or code fences around the JSON object.

The story must cover these seven aspects:
1.  **Ingredient Transparency**: List all main ingredients. For each, provide its typical origin in India, fictional but realistic farmer details, and production method.
2.  **Worker Empowerment**: Detail the contributions of various workers (farmers, cooks, etc.). Include typical wages, common challenges, and how transparency helps.
3.  **Health & Society Analysis**: Compare traditional and modern cooking methods for this dish. Discuss health benefits, affordability, cultural value, and its impact on middle-class families.
4.  **Preparation Steps**: Provide a detailed, step-by-step recipe with timings, quantities, and tools.
5.  **Video Script Simulation**: Create a 4-scene video script tracing one key ingredient's journey from farm to plate. Include visual descriptions, durations, and a social impact message for each scene.
6.  **Next-Generation Vision**: A short, inspiring paragraph about how food transparency can create a healthier, fairer future.`;

    const responseSchema = {
      type: Type.OBJECT,
      properties: {
        ingredientTransparency: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              origin: {
                type: Type.OBJECT,
                properties: { state: { type: Type.STRING }, district: { type: Type.STRING }, farm: { type: Type.STRING } }
              },
              farmer: {
                type: Type.OBJECT,
                properties: { name: { type: Type.STRING }, age: { type: Type.NUMBER }, workingHours: { type: Type.NUMBER } }
              },
              productionMethod: { type: Type.STRING }
            }
          }
        },
        workerEmpowerment: {
          type: Type.OBJECT,
          properties: { explanation: { type: Type.STRING } }
        },
        healthAndSocietyAnalysis: {
          type: Type.OBJECT,
          properties: { comparison: { type: Type.STRING } }
        },
        preparationSteps: {
          type: Type.OBJECT,
          properties: {
            steps: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: { step: { type: Type.NUMBER }, description: { type: Type.STRING }, time: { type: Type.STRING } }
              }
            },
            totalDuration: { type: Type.STRING }
          }
        },
        videoScriptSimulation: {
          type: Type.OBJECT,
          properties: {
            ingredient: { type: Type.STRING },
            scenes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: { scene: { type: Type.NUMBER }, title: { type: Type.STRING }, visual: { type: Type.STRING }, duration: { type: Type.STRING }, socialImpactMessage: { type: Type.STRING } }
              }
            }
          }
        },
        nextGenerationVision: {
          type: Type.OBJECT,
          properties: { vision: { type: Type.STRING } }
        }
      }
    };

    const response = await this.ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
      }
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as DishStory;
  }

  async generateDishImage(prompt: string, aspectRatio: string): Promise<string> {
    const response = await this.ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/png',
          aspectRatio: aspectRatio,
        },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
      const base64ImageBytes = response.generatedImages[0].image.imageBytes;
      return `data:image/png;base64,${base64ImageBytes}`;
    } else {
      throw new Error('No image was generated.');
    }
  }
}
