
export interface Dish {
  name: string;
  description: string;
  image: string;
}

export interface Ingredient {
  name: string;
  origin: {
    state: string;
    district: string;
    farm: string;
  };
  farmer: {
    name: string;
    age: number;
    workingHours: number;
  };
  productionMethod: string;
}

export interface WorkerEmpowerment {
  explanation: string;
}

export interface HealthAndSocietyAnalysis {
  comparison: string;
}

export interface PrepStep {
  step: number;
  description: string;
  time: string;
}

export interface PreparationSteps {
  steps: PrepStep[];
  totalDuration: string;
}

export interface VideoScene {
  scene: number;
  title: string;
  visual: string;
  duration: string;
  socialImpactMessage: string;
}

export interface VideoScriptSimulation {
  ingredient: string;
  scenes: VideoScene[];
}

export interface NextGenerationVision {
    vision: string;
}

export interface DishStory {
  ingredientTransparency: Ingredient[];
  workerEmpowerment: WorkerEmpowerment;
  healthAndSocietyAnalysis: HealthAndSocietyAnalysis;
  preparationSteps: PreparationSteps;
  videoScriptSimulation: VideoScriptSimulation;
  nextGenerationVision: NextGenerationVision;
}
